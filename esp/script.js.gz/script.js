const HubError={None:0,OpenFile:1,FreeSpace:2,CrcMiss:3,SizeMiss:4,Start:5,Write:6,End:7,Abort:8,Timeout:9,Busy:10,Memory:11,WrongClient:12,Forbidden:13,Disabled:14,FsBusy:15,Cancelled:16,};
const Conn={SERIAL:0,BT:1,HTTP:2,MQTT:3,NONE:4,names:['Serial','BT','HTTP','MQTT','None'],};const Modules={UI:(1<<0),INFO:(1<<1),SET:(1<<2),READ:(1<<3),GET:(1<<4),DATA:(1<<5),REBOOT:(1<<6),FILES:(1<<7),FORMAT:(1<<8),DELETE:(1<<9),RENAME:(1<<10),CREATE:(1<<11),FETCH:(1<<12),UPLOAD:(1<<13),OTA:(1<<14),OTA_URL:(1<<15),MQTT:(1<<16),};function http_get(url){return new Promise((res,rej)=>{try{var xhr=new XMLHttpRequest();xhr.onreadystatechange=function(){if(xhr.readyState==4){if(xhr.status==200)res(xhr.responseText);else rej("Error");}}
xhr.ontimeout=()=>rej("Timeout");xhr.onerror=()=>rej("Error");xhr.timeout=this.tout;xhr.open('GET',url,true);xhr.send();}catch(e){rej(e);}});}
function http_fetch(url,onprogress){return new Promise((res,rej)=>{onprogress(0);var xhr=new XMLHttpRequest();xhr.onprogress=(e)=>{onprogress(Math.round(e.loaded*100/e.total));};xhr.onloadend=(e)=>{if(e.loaded&&e.loaded==e.total)res(xhr.responseText);else rej(xhr.responseText);}
xhr.timeout=this.tout;xhr.ontimeout=()=>rej("Timeout");xhr.open('GET',url,true);xhr.send();});}
function http_fetch_blob(url,onprogress){return new Promise((res,rej)=>{onprogress(0);var xhr=new XMLHttpRequest();xhr.responseType='blob';xhr.onprogress=(e)=>{onprogress(Math.round(e.loaded*100/e.total));};xhr.onloadend=(e)=>{if(e.loaded==e.total&&xhr.status==200){var reader=new FileReader();reader.readAsDataURL(xhr.response);reader.onloadend=()=>res(reader.result.split('base64,')[1]);}else{if(xhr.response){xhr.response.text().then(res=>rej(res)).catch(e=>rej(e))}else{rej();}}}
xhr.timeout=this.tout;xhr.ontimeout=()=>rej("Timeout");xhr.open('GET',url,true);xhr.send();});}
function http_post(url,data){return new Promise((res,rej)=>{let xhr=new XMLHttpRequest();xhr.onreadystatechange=()=>{if(xhr.readyState==4){if(xhr.status==200)res(xhr.responseText);else rej(xhr.responseText);}}
xhr.open('POST',url,true);xhr.send(data);});}
function checkIP(ip){return Boolean(ip&&ip.match(/^((25[0-5]|(2[0-4]|1[0-9]|[1-9]|)[0-9])(\.(?!$)|$)){4}$/));}
function getIPs(ip,netmask){if(!checkIP(ip)){alert('Wrong local IP!');return null;}
let ip_a=ip.split('.');let sum_ip=(ip_a[0]<<24)|(ip_a[1]<<16)|(ip_a[2]<<8)|ip_a[3];let cidr=Number(netmask);let mask=~(0xffffffff>>>cidr);let network=0,broadcast=0,start_ip=0,end_ip=0;if(cidr===32){network=sum_ip;broadcast=network;start_ip=network;end_ip=network;}else{network=sum_ip&mask;broadcast=network+(~mask);if(cidr===31){start_ip=network;end_ip=broadcast;}else{start_ip=network+1;end_ip=broadcast-1;}}
let ips=['192.168.4.1'];for(let ip=start_ip;ip<=end_ip;ip++){ips.push(`${(ip >>> 24) & 0xff}.${(ip >>> 16) & 0xff}.${(ip >>> 8) & 0xff}.${ip & 0xff}`);}
return ips;}
class PacketBuffer{_buf='';_tout=null;constructor(hub,conn,byletter=false){this._hub=hub;this._conn=conn;this._byletter=byletter;}
process(data){if(this._tout)clearTimeout(this._tout);this._tout=setTimeout(()=>this._buf='',500);if(this._byletter){for(let t of data){this._buf+=t;this.check();}}else{this._buf+=data;this.check();}}
check(){if(this._buf.startsWith('\n{')&&this._buf.endsWith('}\n')){this._hub._parsePacket(this._conn,this._buf);this._buf='';if(this._tout)clearTimeout(this._tout);this._tout=null;}}};
class Discover{discovering=false;constructor(hub){this._hub=hub;}
_discoverTimer(tout){this.discovering=true;setTimeout(()=>{this.discovering=false;this._hub._checkDiscoverEnd();},tout);}}
class HTTPconn extends Discover{tout_btw=15;tout=3300;constructor(hub){super(hub);}
discover(){if(this.discovering)return;for(let i in this._hub.devices){setTimeout(()=>{let dev=this._hub.devices[i].info;if(dev.ip)this.send(dev.ip,dev.http_port,`hub/${dev.prefix}/${dev.id}`);},this.tout_btw*i);}
this._discoverTimer(this.tout_btw*this._hub.devices.length+this.tout);}
discover_ip(ip,port){if(!checkIP(ip))return false;if(this.discovering)return false;this.send(ip,port,`hub/${this._hub.cfg.prefix}`);this._discoverTimer(this.tout);return true;}
search(){if(this.discovering)return;let ips=getIPs(this._hub.cfg.local_ip,this._hub.cfg.netmask);if(!ips)return;for(let i in ips){setTimeout(()=>{this.send(ips[i],this._hub.cfg.http_port,`hub/${this._hub.cfg.prefix}`);},this.tout_btw*i);}
this._discoverTimer(this.tout_btw*ips.length+this.tout);}
send(ip,port,uri){http_get(`http://${ip}:${port}/${uri}`).then(res=>this._hub._parsePacket(Conn.HTTP,res,ip,port)).catch(e=>{});}
log(t){log('[HTTP] '+t);}
err(e){err('[HTTP] '+e);}};
class WSconn{constructor(device){this.device=device;}
get info(){return this.device.info;}
start(){this._reconnect=true;if(this._ws)return;this._ws=new WebSocket(`ws://${this.info.ip}:${this.info.ws_port}/`,['hub']);this._ws.onopen=()=>{this.log(`${this.info.id} opened`);if(!this._reconnect)this._ws.close();this.device._hub.onWsConnChange(this.info.id,true);};this._ws.onclose=()=>{this.log(`${this.info.id} closed`);this._ws=null;if(this._reconnect)setTimeout(()=>{if(this._reconnect)this.start()},500);this.device._hub.onWsConnChange(this.info.id,false);};this._ws.onerror=()=>{this.log(`${this.info.id} error`);};this._ws.onmessage=(e)=>{this.device.ws_buf.process(e.data);};}
stop(){this._reconnect=false;if(!this._ws||this._ws.readyState>=2)return;this.log(`${this.info.id} close...`);this._ws.close();}
state(){return(this._ws&&this._ws.readyState==1);}
send(text){if(this.state())this._ws.send(text.toString());}
_ws=null;_reconnect=false;log(t){this.device._hub.log('[WS] '+t);}
err(e){this.device._hub.err('[WS] '+e);}}
class Device{constructor(hub){this._hub=hub;this.ws=new WSconn(this);this.mq_buf=new PacketBuffer(hub,Conn.MQTT);this.ws_buf=new PacketBuffer(hub,Conn.HTTP);}
info={id:'undefined',prefix:'undefined',name:'undefined',icon:'',PIN:0,version:'',max_upl:200,modules:0,ota_t:'.bin',ip:null,http_port:null,ws_port:81,http_t:1,};connected(){return!this.conn_lost;}
module(mod){return!(this.info.modules&mod);}
post(cmd,name='',value=''){cmd=cmd.toString();name=name.toString();value=value.toString();if(cmd=='set'){if(!this.module(Modules.SET))return;if(name){if(this.prev_set[name])clearTimeout(this.prev_set[name]);this.prev_set[name]=setTimeout(()=>delete this.prev_set[name],this._hub.skip_prd);}}
let uri0=this.info.prefix+'/'+this.info.id+'/'+this._hub.cfg.client_id+'/'+cmd;let uri=uri0;if(name){uri+='/'+name;if(value)uri+='='+value;}
switch(this.conn){case Conn.HTTP:if(this.ws.state())this.ws.send(uri);else this._hub.http.send(this.info.ip,this.info.http_port,`hub/${uri}`);break;}
if(this.focused){this._reset_ping();this._reset_tout();}}
focus(){this.focused=true;this.post('ui');if(this.conn==Conn.HTTP&&this.info.ws_port){this.ws.start();setTimeout(()=>{if(!this.ws.state())this.ws.stop();},this._hub.tout_prd);}}
unfocus(){this.focused=false;this._stop_ping();this._stop_tout();this.post('unfocus');if(this.conn==Conn.HTTP)this.ws.stop();}
fsStop(){if(this.fs_mode)this.post('fs_abort',this.fs_mode);this._fsEnd();}
fsBusy(){return!!this.fs_mode;}
upload(file,path){if(!this.module(Modules.UPLOAD))return;if(this.fsBusy()){this._hub.onFsUploadError(this.info.id,HubError.FsBusy);return;}
let reader=new FileReader();reader.readAsArrayBuffer(file);reader.onload=(e)=>{if(!e.target.result)return;let buffer=new Uint8Array(e.target.result);if(!path.startsWith('/'))path='/'+path;if(!path.endsWith('/'))path+='/';path+=file.name;if(!confirm('Upload '+path+' ('+buffer.length+' bytes)?')){this._hub.onFsUploadError(this.info.id,HubError.Cancelled);return;}
this._hub.onFsUploadStart(this.info.id);this.fs_mode='upload';this.crc32=crc32(buffer);if(this.conn==Conn.HTTP&&this.info.http_t){let formData=new FormData();formData.append('upload',file);http_post(`http://${this.info.ip}:${this.info.http_port}/hub/upload?path=${path}&crc32=${this.crc32}&client_id=${this._hub.cfg.client_id}&size=${buffer.length}`,formData).then(()=>{this._hub.onFsUploadEnd(this.info.id);this._fsEnd();this.post('files');}).catch((e)=>this._hub.onFsUploadError(this.info.id,e)).finally(()=>this._fsEnd());}else{this.upl_bytes=Array.from(buffer);this.upl_size=this.upl_bytes.length;this.post('upload',path,this.upl_size);this._fsToutStart();}}}
uploadOta(file,type){if(!this.module(Modules.OTA))return;if(this.fsBusy()){this._hub.onOtaError(this.info.id,HubError.FsBusy);return;}
if(!file.name.endsWith(this.info.ota_t)){alert('Wrong file! Use .'+this.info.ota_t);return;}
if(!confirm('Upload OTA '+type+'?'))return;let reader=new FileReader();reader.readAsArrayBuffer(file);reader.onload=(e)=>{if(!e.target.result)return;this._hub.onOtaStart(this.info.id);this.fs_mode='ota';if(this.conn==Conn.HTTP&&this.info.http_t){let formData=new FormData();formData.append(type,file);http_post(`http://${this.info.ip}:${this.info.http_port}/hub/ota?type=${type}&client_id=${this._hub.cfg.client_id}`,formData).then(()=>this._hub.onOtaEnd(this.info.id)).catch((e)=>this._hub.onOtaError(this.info.id,e)).finally(()=>this._fsEnd());}else{let buffer=new Uint8Array(e.target.result);this.upl_bytes=Array.from(buffer);this.upl_size=this.upl_bytes.length;this.post('ota',type);this._fsToutStart();}}}
fetch(idx,path){if(!this.module(Modules.FETCH))return;let id=this.info.id;if(this.fsBusy()){this._hub.onFsFetchError(id,idx,HubError.FsBusy);return;}
this.fs_mode='fetch';this.fet_name=path.split('/').pop();this.fet_index=idx;if(this.conn==Conn.HTTP&&this.info.http_t){http_fetch_blob(`http://${this.info.ip}:${this.info.http_port}/hub/fetch?path=${path}&client_id=${this._hub.cfg.client_id}`,perc=>this._hub.onFsFetchPerc(id,idx,perc)).then(res=>this._hub.onFsFetchEnd(id,this.fet_name,idx,res)).catch(e=>this._hub.onFsFetchError(id,idx,e)).finally(()=>this._fsEnd());}else{this.post('fetch',path);this._fsToutStart();}
this._hub.onFsFetchStart(id,idx);}
resetFiles(){this.files=[];this.file_flag=false;}
addFile(name,path,data){let has=this.files.some(f=>f.name==name);if(!has)this.files.push({name:name,path:path,data:data});if(this.file_flag&&this.files.length==1)this._fetchNextFile();}
checkFiles(){this.file_flag=true;this._fetchNextFile();}
_fetchNextFile(){if(!this.files.length)return;let id=this.info.id;let file=this.files[0];if(this.fsBusy()){this._hub.onFetchError(id,file.name,file.data,HubError.FsBusy);return;}
this.fs_mode='fetch_file';this._hub.onFetchStart(id,file.name);if(this.conn==Conn.HTTP&&this.info.http_t){http_fetch_blob(`http://${this.info.ip}:${this.info.http_port}/hub/fetch?path=${file.path}`,perc=>this._hub.onFetchPerc(id,file.name,perc)).then(res=>this._hub.onFetchEnd(id,file.name,file.data,`data:${getMime(file.path)};base64,${res}`)).catch(e=>this._hub.onFetchError(id,file.name,file.data,Number(e))).finally(()=>{this._fsEnd();this._nextFile();});}else{post('fetch',file.path);}}
_fsEnd(){this.fs_mode=null;this._fsToutEnd();}
_nextFile(){this.files.shift();this._fetchNextFile();}
_checkUpdates(updates){for(let name in updates){if('value'in updates[name]&&this.prev_set[name])delete updates[name].value;if(Object.keys(updates[name]).length)this._hub.onUpdate(this.info.id,name,updates[name]);}}
_parse(type,data){let id=this.info.id;this._stop_tout();if(this.conn_lost){this.conn_lost=false;this._hub.onPingLost(id);if(this.focused)this._hub.onDeviceConnChange(id,true);}
switch(type){case'OK':break;case'update':this._checkUpdates(data.updates);break;case'fetch_start':if(this.fs_mode!='fetch'&&this.fs_mode!='fetch_file')break;this.fet_len=data.len;this.fet_buf='';this.post('fetch_next');this._fsToutStart();if(this.fs_mode=='fetch'){this._hub.onFsFetchPerc(id,this.fet_index,0);}else{this._hub.onFetchPerc(id,this.files[0].name,0);}
break;case'fetch_chunk':if((this.fs_mode!='fetch'&&this.fs_mode!='fetch_file')||this.fet_buf==null)break;this.fet_buf+=atob(data.data);if(data.last){let crc=crc32(this.fet_buf);if(this.fet_buf.length==this.fet_len&&crc==data.crc32){let b64=btoa(this.fet_buf);if(this.fs_mode=='fetch'){this._hub.onFsFetchEnd(id,this.fet_name,this.fet_index,b64);}else{let file=this.files[0];this._hub.onFetchEnd(id,file.name,file.data,`data:${getMime(file.path)};base64,${b64}`);}}else{let code=(crc!=data.crc32)?HubError.CrcMiss:HubError.SizeMiss;if(this.fs_mode=='fetch'){this._hub.onFsFetchError(id,this.fet_index,code);}else{this._hub.onFetchError(id,this.files[0].name,this.files[0].data,code);}}
this.fet_buf=null;if(this.fs_mode=='fetch_file'){this._fsEnd();this._nextFile();}else{this._fsEnd();}}else{let perc=Math.round(this.fet_buf.length/this.fet_len*100);if(this.fs_mode=='fetch'){this._hub.onFsFetchPerc(id,this.fet_index,perc);}else{this._hub.onFetchPerc(id,this.files[0].name,perc);}
this.post('fetch_next');this._fsToutStart();}
break;case'fetch_err':if(this.fs_mode!='fetch'&&this.fs_mode!='fetch_file')break;this.fet_buf=null;if(this.fs_mode=='fetch'){this._hub.onFsFetchError(id,this.fet_index,data.code);this._fsEnd();}else{this._hub.onFetchError(id,this.files[0].name,this.files[0].data,data.code);this._fsEnd();this._nextFile();}
break;case'upload_next':if(this.fs_mode!='upload')break;this._uploadNextChunk();this._fsToutStart();break;case'upload_done':if(this.fs_mode!='upload')break;this._hub.onFsUploadEnd(id);this._fsEnd();this.post('files');break;case'upload_err':if(this.fs_mode!='upload')break;this._hub.onFsUploadError(id,data.code);this._fsEnd();break;case'ota_next':if(this.fs_mode!='ota')break;this._otaNextChunk();this._fsToutStart();break;case'ota_done':if(this.fs_mode!='ota')break;this._hub.onOtaEnd(id);this._fsEnd();break;case'ota_err':if(this.fs_mode!='ota')break;this._hub.onOtaError(id,data.code);this._fsEnd();break;}}
_stop_tout(){if(this.tout){this._hub.onWaitAnswer(this.info.id,false);clearTimeout(this.tout);this.tout=null;}}
_reset_tout(){if(this.tout)return;this._hub.onWaitAnswer(this.info.id,true);this.tout=setTimeout(()=>{if(this.focused)this._hub.onDeviceConnChange(this.info.id,false);this.conn_lost=true;this._stop_tout();},this._hub.tout_prd);}
_stop_ping(){if(this.ping)clearInterval(this.ping);this.ping=null;}
_reset_ping(){this._stop_ping();this.ping=setInterval(()=>{if(this.conn_lost)this._hub.onPingLost(this.info.id);else this.post('ping');},this._hub.ping_prd);}
_otaNextChunk(){let i=0;let data='';while(true){if(!this.upl_bytes.length)break;data+=String.fromCharCode(this.upl_bytes.shift());if(++i>=this.info.max_upl*3/4-60)break;}
this._hub.onOtaPerc(this.info.id,Math.round((this.upl_size-this.upl_bytes.length)/this.upl_size*100));this.post('ota_chunk',(this.upl_bytes.length)?'next':'last',window.btoa(data));}
_uploadNextChunk(){if(this.crc32!==null){this.post('upload_chunk','crc',this.crc32);this.crc32=null;return;}
let i=0;let data='';while(true){if(!this.upl_bytes.length)break;data+=String.fromCharCode(this.upl_bytes.shift());if(++i>=this.info.max_upl*3/4-60)break;}
this._hub.onFsUploadPerc(this.info.id,Math.round((this.upl_size-this.upl_bytes.length)/this.upl_size*100));this.post('upload_chunk',(this.upl_bytes.length)?'next':'last',window.btoa(data));}
_fsToutStart(){this._fsToutEnd();this.fs_tout=setTimeout(()=>{switch(this.fs_mode){case'upload':this._hub.onFsUploadError(this.info.id,HubError.Timeout);break;case'fetch':this._hub.onFsFetchError(this.info.id,this.fet_index,HubError.Timeout);this.fet_buf=null;break;case'fetch_file':if(!this.files[0])return;this._hub.onFetchError(this.info.id,this.files[0].name,this.files[0].data,HubError.Timeout);this.fet_buf=null;this._nextFile();break;case'ota':this._hub.onOtaError(this.info.id,HubError.Timeout);break;}
this.fsStop();},this._hub.tout_prd);}
_fsToutEnd(){if(this.fs_tout)clearTimeout(this.fs_tout);}
_log(t){this._hub.log(this.info.name+' '+t);}
_err(e){this._hub.log(this.info.name+' '+e);}
conn=Conn.NONE;conn_arr=[0,0,0,0];granted=false;focused=false;tout=null;ping=null;conn_lost=false;prev_set={};fs_mode=null;fs_tout=null;crc32=null;upl_bytes=null;upl_size=null;fet_name='';fet_index=0;fet_buf=null;fet_len=0;files=[];file_flag=false;cfg_flag=false;};
class GyverHub{onHubError(text){}
onSaveDevices(){}
onAddDevice(dev){}
onUpdDevice(dev){}
onDiscoverEnd(){}
onDiscover(id,conn){}
onUpdate(id,name,data){}
onInfo(id,info){}
onFsbr(id,fs,total,used){}
onPrint(id,text,color){}
onUi(id,controls,conn,ip){}
onData(id,data){}
onAlert(id,text){}
onNotice(id,text,color){}
onPush(id,text){}
onAck(id,name){}
onDeviceConnChange(id,state){}
onWsConnChange(id,state){}
onWaitAnswer(id,state){}
onPingLost(id){}
onError(id,code){}
onFsError(id){}
onFsUploadStart(id){}
onFsUploadEnd(id){}
onFsUploadError(id,code){}
onFsUploadPerc(id,perc){}
onOtaStart(id){}
onOtaEnd(id){}
onOtaError(id,code){}
onOtaPerc(id,perc){}
onOtaUrlEnd(id){}
onOtaUrlError(id,code){}
onFsFetchStart(id,index){}
onFsFetchEnd(id,name,index,data){}
onFsFetchError(id,index,code){}
onFsFetchPerc(id,index,perc){}
onFetchStart(id,name){}
onFetchEnd(id,name,data,file){}
onFetchError(id,name,data,code){}
onFetchPerc(id,name,perc){}
devices=[];cfg={prefix:'MyDevices',client_id:new Date().getTime().toString(16).slice(-8),use_local:false,local_ip:'192.168.1.1',netmask:24,http_port:80,use_bt:false,use_serial:false,baudrate:115200,use_mqtt:false,mq_host:'test.mosquitto.org',mq_port:'8081',mq_login:'',mq_pass:'',api_ver:1};skip_prd=1000;tout_prd=2500;ping_prd=3000;constructor(){this.http=new HTTPconn(this);}
begin(){}
post(id,cmd,name='',value=''){this.dev(id).post(cmd,name,value);}
discover(){for(let dev of this.devices){dev.conn=Conn.NONE;dev.conn_arr=[0,0,0,0];}
if(this.cfg.use_local&&!isSSL())this.http.discover();this._checkDiscoverEnd();}
search(){if(this.cfg.use_local&&!isSSL())this.http.search();this._checkDiscoverEnd();}
dev(id){if(!id)return null;for(let d of this.devices){if(d.info.id==id)return d;}
return null;}
export(){let devs=[];for(let d of this.devices){devs.push(d.info);}
return JSON.stringify(devs);}
import(str){let devsi=JSON.parse(str);this.devices=[];for(let di of devsi){let dev=new Device(this);for(let key in di){dev.info[key]=di[key];}
this.devices.push(dev);}}
delete(id){for(let i in this.devices){if(this.devices[i].info.id==id){this.devices.splice(i,1);this.onSaveDevices();return;}}}
addDevice(data,conn=Conn.NONE){let device=this.dev(data.id);let flag=false;if(device){for(let key in data){if(device.info[key]!=data[key]){device.info[key]=data[key];flag=true;}}
device.conn_arr[conn]=1;if(device.conn>conn){device.conn=conn;flag=true;}
if(flag)this.onUpdDevice(device.info);}else{device=new Device(this);for(let key in data){device.info[key]=data[key];}
device.conn=conn;this.devices.push(device);this.onAddDevice(device.info);flag=true;}
if(flag){this.onSaveDevices();}}
moveDevice(id,dir){if(this.devices.length==1)return;let idx=0;for(let d of this.devices){if(d.info.id==id)break;idx++;}
if((dir==1&&idx<=this.devices.length-2)||(dir==-1&&idx>=1)){let b=this.devices[idx];this.devices[idx]=this.devices[idx+dir];this.devices[idx+dir]=b;}}
log(t){console.log('Log: '+t);}
err(e){console.log('Error: '+e.toString());this.onHubError(e.toString());}
_checkDiscoverEnd(){if(!this._discovering())this.onDiscoverEnd();}
_discovering(){return this.http.discovering;}
_preflist(){let list=[this.cfg.prefix];for(let dev of this.devices){if(!list.includes(dev.info.prefix))list.push(dev.info.prefix);}
return list;}
_parsePacket(conn,data,ip=null,port=null){data=data.trim().replaceAll(/([^\\])\\([^\"\\nrt])/ig,"$1\\\\$2").replaceAll(/\t/ig,"\\t").replaceAll(/\n/ig,"\\n").replaceAll(/\r/ig,"\\r");try{data=JSON.parse(data);}catch(e){console.log('Wrong packet (JSON): '+e+' in: '+data);this.err('Wrong packet (JSON)');return;}
if(!data.id)return this.err('Wrong packet (ID)');if(data.client&&this.cfg.client_id!=data.client)return;let type=data.type;delete data.type;if(type=='discover'&&this._discovering()){if(conn==Conn.HTTP){data.ip=ip;data.http_port=port;}
this.addDevice(data,conn);}
let device=this.dev(data.id);if(device){device._parse(type,data);let id=data.id;switch(type){case'error':this.onError(id,data.code);break;case'refresh':this.post(id,'ui');break;case'script':eval(data.script);break;case'ack':this.onAck(id,data.name);break;case'fs_err':this.onFsError(id);break;case'info':this.onInfo(id,data.info);break;case'files':this.onFsbr(id,data.fs,data.total,data.used);break;case'print':this.onPrint(id,data.text,data.color);break;case'discover':if(this._discovering())this.onDiscover(id,conn);break;case'ui':if(device.module(Modules.UI))this.onUi(id,data.controls,conn,device.info.ip);this.post(id,'unix',Math.floor(new Date().getTime()/1000));break;case'data':if(device.module(Modules.DATA))this.onData(id,data.data);break;case'alert':this.onAlert(id,data.text);break;case'notice':this.onNotice(id,data.text,intToCol(data.color));break;case'push':this.onPush(id,data.text);break;case'ota_url_ok':this.onOtaUrlEnd(id);break;case'ota_url_err':this.onOtaUrlError(id,data.code);break;}}}};
(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";window.sortPaths=require("./sort-paths.js");
},{"./sort-paths.js":3}],2:[function(require,module,exports){
"use strict";function splitRetain(e,t,r){if(r=defaults(r,{}),r.leadingSeparator=defaults(r.leadingSeparator,!1),assert.type(e,"string","`string` is not a string"),assert("string"==typeof t||t instanceof RegExp,"invalid `separator` type"),assert.type(r,"object","invalid `options` type"),assert.type(r.leadingSeparator,"boolean","invalid `options.leadingSeparator` type"),0===e.length)return[""];t=separatorToRegex(t);var n=e.split(t);if(1===n.length)return n;var s=[];for(r.leadingSeparator&&s.push(n.shift());n.length>0;)1===n.length?s.push(n.shift()):s.push(n.shift()+n.shift());return""===s[0]&&s.shift(),""===s[s.length-1]&&s.pop(),s}function separatorToRegex(e){return e instanceof RegExp?e:new RegExp("("+escapeRegex(e)+")","g")}function escapeRegex(e){return e.replace(/[-[\]{}()*+?.,\\^$|#\s]/g,"\\$&")}function assert(e,t){if(!e)throw new Error(t)}function defaults(e,t){return void 0===e?t:e}exports=module.exports=splitRetain,splitRetain.VERSION="1.0.1",assert.type=function(e,t,r){if(typeof e!==t)throw new Error(r)};
},{}],3:[function(require,module,exports){
"use strict";function sortPaths(t){assert(arguments.length>=2,"too few arguments"),assert(arguments.length<=3,"too many arguments");var r,e;2===arguments.length?(r=identity,e=arguments[1]):(r=arguments[1],e=arguments[2]),assert(isArray(t),"items is not an list"),assert(isFunction(r),"iteratee is not a function"),assert("string"==typeof e,"dirSeparator is not a String"),assert(1===e.length,"dirSeparator must be a single character");var n=t.map(function(t){var n=r(t);return assert("string"==typeof n,"item or iteratee(item) must be a String"),{item:t,pathTokens:splitRetain(n,e)}});return n.sort(createItemDTOComparator(e)),n.map(function(t){return t.item})}function createItemDTOComparator(t){return function(r,e){for(var n=r.pathTokens,a=e.pathTokens,o=0,i=Math.max(n.length,a.length);o<i;o++){if(!(o in n))return-1;if(!(o in a))return 1;var s=n[o].toLowerCase(),u=a[o].toLowerCase();if(s!==u){var c=s[s.length-1]===t;return c===(u[u.length-1]===t)?s<u?-1:1:c?1:-1}}return 0}}function assert(t,r){if(!t)throw new Error(r)}function identity(t){return t}function isFunction(t){return Boolean(t)&&"[object Function]"===Object.prototype.toString.call(t)}function isArray(t){return Boolean(t)&&"[object Array]"===Object.prototype.toString.call(t)}var splitRetain=require("split-retain");module.exports=sortPaths,sortPaths.VERSION="1.1.1";
},{"split-retain":2}]},{},[1]);
!function(t,e){"object"==typeof exports&&"object"==typeof module?module.exports=e():"function"==typeof define&&define.amd?define([],e):"object"==typeof exports?exports.Pickr=e():t.Pickr=e()}(self,(function(){return(()=>{"use strict";var t={d:(e,o)=>{for(var n in o)t.o(o,n)&&!t.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:o[n]})},o:(t,e)=>Object.prototype.hasOwnProperty.call(t,e),r:t=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})}},e={};t.d(e,{default:()=>L});var o={};function n(t,e,o,n,i={}){e instanceof HTMLCollection||e instanceof NodeList?e=Array.from(e):Array.isArray(e)||(e=[e]),Array.isArray(o)||(o=[o]);for(const s of e)for(const e of o)s[t](e,n,{capture:!1,...i});return Array.prototype.slice.call(arguments,1)}t.r(o),t.d(o,{adjustableInputNumbers:()=>p,createElementFromString:()=>r,createFromTemplate:()=>a,eventPath:()=>l,off:()=>s,on:()=>i,resolveElement:()=>c});const i=n.bind(null,"addEventListener"),s=n.bind(null,"removeEventListener");function r(t){const e=document.createElement("div");return e.innerHTML=t.trim(),e.firstElementChild}function a(t){const e=(t,e)=>{const o=t.getAttribute(e);return t.removeAttribute(e),o},o=(t,n={})=>{const i=e(t,":obj"),s=e(t,":ref"),r=i?n[i]={}:n;s&&(n[s]=t);for(const n of Array.from(t.children)){const t=e(n,":arr"),i=o(n,t?{}:r);t&&(r[t]||(r[t]=[])).push(Object.keys(i).length?i:n)}return n};return o(r(t))}function l(t){let e=t.path||t.composedPath&&t.composedPath();if(e)return e;let o=t.target.parentElement;for(e=[t.target,o];o=o.parentElement;)e.push(o);return e.push(document,window),e}function c(t){return t instanceof Element?t:"string"==typeof t?t.split(/>>/g).reduce(((t,e,o,n)=>(t=t.querySelector(e),o<n.length-1?t.shadowRoot:t)),document):null}function p(t,e=(t=>t)){function o(o){const n=[.001,.01,.1][Number(o.shiftKey||2*o.ctrlKey)]*(o.deltaY<0?1:-1);let i=0,s=t.selectionStart;t.value=t.value.replace(/[\d.]+/g,((t,o)=>o<=s&&o+t.length>=s?(s=o,e(Number(t),n,i)):(i++,t))),t.focus(),t.setSelectionRange(s,s),o.preventDefault(),t.dispatchEvent(new Event("input"))}i(t,"focus",(()=>i(window,"wheel",o,{passive:!1}))),i(t,"blur",(()=>s(window,"wheel",o)))}const{min:u,max:h,floor:d,round:m}=Math;function f(t,e,o){e/=100,o/=100;const n=d(t=t/360*6),i=t-n,s=o*(1-e),r=o*(1-i*e),a=o*(1-(1-i)*e),l=n%6;return[255*[o,r,s,s,a,o][l],255*[a,o,o,r,s,s][l],255*[s,s,a,o,o,r][l]]}function v(t,e,o){const n=(2-(e/=100))*(o/=100)/2;return 0!==n&&(e=1===n?0:n<.5?e*o/(2*n):e*o/(2-2*n)),[t,100*e,100*n]}function b(t,e,o){const n=u(t/=255,e/=255,o/=255),i=h(t,e,o),s=i-n;let r,a;if(0===s)r=a=0;else{a=s/i;const n=((i-t)/6+s/2)/s,l=((i-e)/6+s/2)/s,c=((i-o)/6+s/2)/s;t===i?r=c-l:e===i?r=1/3+n-c:o===i&&(r=2/3+l-n),r<0?r+=1:r>1&&(r-=1)}return[360*r,100*a,100*i]}function y(t,e,o,n){e/=100,o/=100;return[...b(255*(1-u(1,(t/=100)*(1-(n/=100))+n)),255*(1-u(1,e*(1-n)+n)),255*(1-u(1,o*(1-n)+n)))]}function g(t,e,o){e/=100;const n=2*(e*=(o/=100)<.5?o:1-o)/(o+e)*100,i=100*(o+e);return[t,isNaN(n)?0:n,i]}function _(t){return b(...t.match(/.{2}/g).map((t=>parseInt(t,16))))}function w(t){t=t.match(/^[a-zA-Z]+$/)?function(t){if("black"===t.toLowerCase())return"#000";const e=document.createElement("canvas").getContext("2d");return e.fillStyle=t,"#000"===e.fillStyle?null:e.fillStyle}(t):t;const e={cmyk:/^cmyk[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)/i,rgba:/^((rgba)|rgb)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,hsla:/^((hsla)|hsl)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,hsva:/^((hsva)|hsv)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,hexa:/^#?(([\dA-Fa-f]{3,4})|([\dA-Fa-f]{6})|([\dA-Fa-f]{8}))$/i},o=t=>t.map((t=>/^(|\d+)\.\d+|\d+$/.test(t)?Number(t):void 0));let n;t:for(const i in e){if(!(n=e[i].exec(t)))continue;const s=t=>!!n[2]==("number"==typeof t);switch(i){case"cmyk":{const[,t,e,s,r]=o(n);if(t>100||e>100||s>100||r>100)break t;return{values:y(t,e,s,r),type:i}}case"rgba":{const[,,,t,e,r,a]=o(n);if(t>255||e>255||r>255||a<0||a>1||!s(a))break t;return{values:[...b(t,e,r),a],a,type:i}}case"hexa":{let[,t]=n;4!==t.length&&3!==t.length||(t=t.split("").map((t=>t+t)).join(""));const e=t.substring(0,6);let o=t.substring(6);return o=o?parseInt(o,16)/255:void 0,{values:[..._(e),o],a:o,type:i}}case"hsla":{const[,,,t,e,r,a]=o(n);if(t>360||e>100||r>100||a<0||a>1||!s(a))break t;return{values:[...g(t,e,r),a],a,type:i}}case"hsva":{const[,,,t,e,r,a]=o(n);if(t>360||e>100||r>100||a<0||a>1||!s(a))break t;return{values:[t,e,r,a],a,type:i}}}}return{values:null,type:null}}function A(t=0,e=0,o=0,n=1){const i=(t,e)=>(o=-1)=>e(~o?t.map((t=>Number(t.toFixed(o)))):t),s={h:t,s:e,v:o,a:n,toHSVA(){const t=[s.h,s.s,s.v,s.a];return t.toString=i(t,(t=>`hsva(${t[0]}, ${t[1]}%, ${t[2]}%, ${s.a})`)),t},toHSLA(){const t=[...v(s.h,s.s,s.v),s.a];return t.toString=i(t,(t=>`hsla(${t[0]}, ${t[1]}%, ${t[2]}%, ${s.a})`)),t},toRGBA(){const t=[...f(s.h,s.s,s.v),s.a];return t.toString=i(t,(t=>`rgba(${t[0]}, ${t[1]}, ${t[2]}, ${s.a})`)),t},toCMYK(){const t=function(t,e,o){const n=f(t,e,o),i=n[0]/255,s=n[1]/255,r=n[2]/255,a=u(1-i,1-s,1-r);return[100*(1===a?0:(1-i-a)/(1-a)),100*(1===a?0:(1-s-a)/(1-a)),100*(1===a?0:(1-r-a)/(1-a)),100*a]}(s.h,s.s,s.v);return t.toString=i(t,(t=>`cmyk(${t[0]}%, ${t[1]}%, ${t[2]}%, ${t[3]}%)`)),t},toHEXA(){const t=function(t,e,o){return f(t,e,o).map((t=>m(t).toString(16).padStart(2,"0")))}(s.h,s.s,s.v),e=s.a>=1?"":Number((255*s.a).toFixed(0)).toString(16).toUpperCase().padStart(2,"0");return e&&t.push(e),t.toString=()=>`#${t.join("").toUpperCase()}`,t},clone:()=>A(s.h,s.s,s.v,s.a)};return s}const C=t=>Math.max(Math.min(t,1),0);function $(t){const e={options:Object.assign({lock:null,onchange:()=>0,onstop:()=>0},t),_keyboard(t){const{options:o}=e,{type:n,key:i}=t;if(document.activeElement===o.wrapper){const{lock:o}=e.options,s="ArrowUp"===i,r="ArrowRight"===i,a="ArrowDown"===i,l="ArrowLeft"===i;if("keydown"===n&&(s||r||a||l)){let n=0,i=0;"v"===o?n=s||r?1:-1:"h"===o?n=s||r?-1:1:(i=s?-1:a?1:0,n=l?-1:r?1:0),e.update(C(e.cache.x+.01*n),C(e.cache.y+.01*i)),t.preventDefault()}else i.startsWith("Arrow")&&(e.options.onstop(),t.preventDefault())}},_tapstart(t){i(document,["mouseup","touchend","touchcancel"],e._tapstop),i(document,["mousemove","touchmove"],e._tapmove),t.cancelable&&t.preventDefault(),e._tapmove(t)},_tapmove(t){const{options:o,cache:n}=e,{lock:i,element:s,wrapper:r}=o,a=r.getBoundingClientRect();let l=0,c=0;if(t){const e=t&&t.touches&&t.touches[0];l=t?(e||t).clientX:0,c=t?(e||t).clientY:0,l<a.left?l=a.left:l>a.left+a.width&&(l=a.left+a.width),c<a.top?c=a.top:c>a.top+a.height&&(c=a.top+a.height),l-=a.left,c-=a.top}else n&&(l=n.x*a.width,c=n.y*a.height);"h"!==i&&(s.style.left=`calc(${l/a.width*100}% - ${s.offsetWidth/2}px)`),"v"!==i&&(s.style.top=`calc(${c/a.height*100}% - ${s.offsetHeight/2}px)`),e.cache={x:l/a.width,y:c/a.height};const p=C(l/a.width),u=C(c/a.height);switch(i){case"v":return o.onchange(p);case"h":return o.onchange(u);default:return o.onchange(p,u)}},_tapstop(){e.options.onstop(),s(document,["mouseup","touchend","touchcancel"],e._tapstop),s(document,["mousemove","touchmove"],e._tapmove)},trigger(){e._tapmove()},update(t=0,o=0){const{left:n,top:i,width:s,height:r}=e.options.wrapper.getBoundingClientRect();"h"===e.options.lock&&(o=t),e._tapmove({clientX:n+s*t,clientY:i+r*o})},destroy(){const{options:t,_tapstart:o,_keyboard:n}=e;s(document,["keydown","keyup"],n),s([t.wrapper,t.element],"mousedown",o),s([t.wrapper,t.element],"touchstart",o,{passive:!1})}},{options:o,_tapstart:n,_keyboard:r}=e;return i([o.wrapper,o.element],"mousedown",n),i([o.wrapper,o.element],"touchstart",n,{passive:!1}),i(document,["keydown","keyup"],r),e}function k(t={}){t=Object.assign({onchange:()=>0,className:"",elements:[]},t);const e=i(t.elements,"click",(e=>{t.elements.forEach((o=>o.classList[e.target===o?"add":"remove"](t.className))),t.onchange(e),e.stopPropagation()}));return{destroy:()=>s(...e)}}const S={variantFlipOrder:{start:"sme",middle:"mse",end:"ems"},positionFlipOrder:{top:"tbrl",right:"rltb",bottom:"btrl",left:"lrbt"},position:"bottom",margin:8},O=(t,e,o)=>{const{container:n,margin:i,position:s,variantFlipOrder:r,positionFlipOrder:a}={container:document.documentElement.getBoundingClientRect(),...S,...o},{left:l,top:c}=e.style;e.style.left="0",e.style.top="0";const p=t.getBoundingClientRect(),u=e.getBoundingClientRect(),h={t:p.top-u.height-i,b:p.bottom+i,r:p.right+i,l:p.left-u.width-i},d={vs:p.left,vm:p.left+p.width/2+-u.width/2,ve:p.left+p.width-u.width,hs:p.top,hm:p.bottom-p.height/2-u.height/2,he:p.bottom-u.height},[m,f="middle"]=s.split("-"),v=a[m],b=r[f],{top:y,left:g,bottom:_,right:w}=n;for(const t of v){const o="t"===t||"b"===t,n=h[t],[i,s]=o?["top","left"]:["left","top"],[r,a]=o?[u.height,u.width]:[u.width,u.height],[l,c]=o?[_,w]:[w,_],[p,m]=o?[y,g]:[g,y];if(!(n<p||n+r>l))for(const r of b){const l=d[(o?"v":"h")+r];if(!(l<m||l+a>c))return e.style[s]=l-u[s]+"px",e.style[i]=n-u[i]+"px",t+r}}return e.style.left=l,e.style.top=c,null};function E(t,e,o){return e in t?Object.defineProperty(t,e,{value:o,enumerable:!0,configurable:!0,writable:!0}):t[e]=o,t}class L{constructor(t){E(this,"_initializingActive",!0),E(this,"_recalc",!0),E(this,"_nanopop",null),E(this,"_root",null),E(this,"_color",A()),E(this,"_lastColor",A()),E(this,"_swatchColors",[]),E(this,"_setupAnimationFrame",null),E(this,"_eventListener",{init:[],save:[],hide:[],show:[],clear:[],change:[],changestop:[],cancel:[],swatchselect:[]}),this.options=t=Object.assign({...L.DEFAULT_OPTIONS},t);const{swatches:e,components:o,theme:n,sliders:i,lockOpacity:s,padding:r}=t;["nano","monolith"].includes(n)&&!i&&(t.sliders="h"),o.interaction||(o.interaction={});const{preview:a,opacity:l,hue:c,palette:p}=o;o.opacity=!s&&l,o.palette=p||a||l||c,this._preBuild(),this._buildComponents(),this._bindEvents(),this._finalBuild(),e&&e.length&&e.forEach((t=>this.addSwatch(t)));const{button:u,app:h}=this._root;this._nanopop=((t,e,o)=>{const n="object"!=typeof t||t instanceof HTMLElement?{reference:t,popper:e,...o}:t;return{update(t=n){const{reference:e,popper:o}=Object.assign(n,t);if(!o||!e)throw new Error("Popper- or reference-element missing.");return O(e,o,n)}}})(u,h,{margin:r}),u.setAttribute("role","button"),u.setAttribute("aria-label",this._t("btn:toggle"));const d=this;this._setupAnimationFrame=requestAnimationFrame((function e(){if(!h.offsetWidth)return requestAnimationFrame(e);d.setColor(t.default),d._rePositioningPicker(),t.defaultRepresentation&&(d._representation=t.defaultRepresentation,d.setColorRepresentation(d._representation)),t.showAlways&&d.show(),d._initializingActive=!1,d._emit("init")}))}_preBuild(){const{options:t}=this;for(const e of["el","container"])t[e]=c(t[e]);this._root=(t=>{const{components:e,useAsButton:o,inline:n,appClass:i,theme:s,lockOpacity:r}=t.options,l=t=>t?"":'style="display:none" hidden',c=e=>t._t(e),p=a(`\n      <div :ref="root" class="pickr">\n\n        ${o?"":'<button type="button" :ref="button" class="pcr-button"></button>'}\n\n        <div :ref="app" class="pcr-app ${i||""}" data-theme="${s}" ${n?'style="position: unset"':""} aria-label="${c("ui:dialog")}" role="window">\n          <div class="pcr-selection" ${l(e.palette)}>\n            <div :obj="preview" class="pcr-color-preview" ${l(e.preview)}>\n              <button type="button" :ref="lastColor" class="pcr-last-color" aria-label="${c("btn:last-color")}"></button>\n              <div :ref="currentColor" class="pcr-current-color"></div>\n            </div>\n\n            <div :obj="palette" class="pcr-color-palette">\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="palette" class="pcr-palette" tabindex="0" aria-label="${c("aria:palette")}" role="listbox"></div>\n            </div>\n\n            <div :obj="hue" class="pcr-color-chooser" ${l(e.hue)}>\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="slider" class="pcr-hue pcr-slider" tabindex="0" aria-label="${c("aria:hue")}" role="slider"></div>\n            </div>\n\n            <div :obj="opacity" class="pcr-color-opacity" ${l(e.opacity)}>\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="slider" class="pcr-opacity pcr-slider" tabindex="0" aria-label="${c("aria:opacity")}" role="slider"></div>\n            </div>\n          </div>\n\n          <div class="pcr-swatches ${e.palette?"":"pcr-last"}" :ref="swatches"></div>\n\n          <div :obj="interaction" class="pcr-interaction" ${l(Object.keys(e.interaction).length)}>\n            <input :ref="result" class="pcr-result" type="text" spellcheck="false" ${l(e.interaction.input)} aria-label="${c("aria:input")}">\n\n            <input :arr="options" class="pcr-type" data-type="HEXA" value="${r?"HEX":"HEXA"}" type="button" ${l(e.interaction.hex)}>\n            <input :arr="options" class="pcr-type" data-type="RGBA" value="${r?"RGB":"RGBA"}" type="button" ${l(e.interaction.rgba)}>\n            <input :arr="options" class="pcr-type" data-type="HSLA" value="${r?"HSL":"HSLA"}" type="button" ${l(e.interaction.hsla)}>\n            <input :arr="options" class="pcr-type" data-type="HSVA" value="${r?"HSV":"HSVA"}" type="button" ${l(e.interaction.hsva)}>\n            <input :arr="options" class="pcr-type" data-type="CMYK" value="CMYK" type="button" ${l(e.interaction.cmyk)}>\n\n            <input :ref="save" class="pcr-save" value="${c("btn:save")}" type="button" ${l(e.interaction.save)} aria-label="${c("aria:btn:save")}">\n            <input :ref="cancel" class="pcr-cancel" value="${c("btn:cancel")}" type="button" ${l(e.interaction.cancel)} aria-label="${c("aria:btn:cancel")}">\n            <input :ref="clear" class="pcr-clear" value="${c("btn:clear")}" type="button" ${l(e.interaction.clear)} aria-label="${c("aria:btn:clear")}">\n          </div>\n        </div>\n      </div>\n    `),u=p.interaction;return u.options.find((t=>!t.hidden&&!t.classList.add("active"))),u.type=()=>u.options.find((t=>t.classList.contains("active"))),p})(this),t.useAsButton&&(this._root.button=t.el),t.container.appendChild(this._root.root)}_finalBuild(){const t=this.options,e=this._root;if(t.container.removeChild(e.root),t.inline){const o=t.el.parentElement;t.el.nextSibling?o.insertBefore(e.app,t.el.nextSibling):o.appendChild(e.app)}else t.container.appendChild(e.app);t.useAsButton?t.inline&&t.el.remove():t.el.parentNode.replaceChild(e.root,t.el),t.disabled&&this.disable(),t.comparison||(e.button.style.transition="none",t.useAsButton||(e.preview.lastColor.style.transition="none")),this.hide()}_buildComponents(){const t=this,e=this.options.components,o=(t.options.sliders||"v").repeat(2),[n,i]=o.match(/^[vh]+$/g)?o:[],s=()=>this._color||(this._color=this._lastColor.clone()),r={palette:$({element:t._root.palette.picker,wrapper:t._root.palette.palette,onstop:()=>t._emit("changestop","slider",t),onchange(o,n){if(!e.palette)return;const i=s(),{_root:r,options:a}=t,{lastColor:l,currentColor:c}=r.preview;t._recalc&&(i.s=100*o,i.v=100-100*n,i.v<0&&(i.v=0),t._updateOutput("slider"));const p=i.toRGBA().toString(0);this.element.style.background=p,this.wrapper.style.background=`\n                        linear-gradient(to top, rgba(0, 0, 0, ${i.a}), transparent),\n                        linear-gradient(to left, hsla(${i.h}, 100%, 50%, ${i.a}), rgba(255, 255, 255, ${i.a}))\n                    `,a.comparison?a.useAsButton||t._lastColor||l.style.setProperty("--pcr-color",p):(r.button.style.setProperty("--pcr-color",p),r.button.classList.remove("clear"));const u=i.toHEXA().toString();for(const{el:e,color:o}of t._swatchColors)e.classList[u===o.toHEXA().toString()?"add":"remove"]("pcr-active");c.style.setProperty("--pcr-color",p)}}),hue:$({lock:"v"===i?"h":"v",element:t._root.hue.picker,wrapper:t._root.hue.slider,onstop:()=>t._emit("changestop","slider",t),onchange(o){if(!e.hue||!e.palette)return;const n=s();t._recalc&&(n.h=360*o),this.element.style.backgroundColor=`hsl(${n.h}, 100%, 50%)`,r.palette.trigger()}}),opacity:$({lock:"v"===n?"h":"v",element:t._root.opacity.picker,wrapper:t._root.opacity.slider,onstop:()=>t._emit("changestop","slider",t),onchange(o){if(!e.opacity||!e.palette)return;const n=s();t._recalc&&(n.a=Math.round(100*o)/100),this.element.style.background=`rgba(0, 0, 0, ${n.a})`,r.palette.trigger()}}),selectable:k({elements:t._root.interaction.options,className:"active",onchange(e){t._representation=e.target.getAttribute("data-type").toUpperCase(),t._recalc&&t._updateOutput("swatch")}})};this._components=r}_bindEvents(){const{_root:t,options:e}=this,o=[i(t.interaction.clear,"click",(()=>this._clearColor())),i([t.interaction.cancel,t.preview.lastColor],"click",(()=>{this.setHSVA(...(this._lastColor||this._color).toHSVA(),!0),this._emit("cancel")})),i(t.interaction.save,"click",(()=>{!this.applyColor()&&!e.showAlways&&this.hide()})),i(t.interaction.result,["keyup","input"],(t=>{this.setColor(t.target.value,!0)&&!this._initializingActive&&(this._emit("change",this._color,"input",this),this._emit("changestop","input",this)),t.stopImmediatePropagation()})),i(t.interaction.result,["focus","blur"],(t=>{this._recalc="blur"===t.type,this._recalc&&this._updateOutput(null)})),i([t.palette.palette,t.palette.picker,t.hue.slider,t.hue.picker,t.opacity.slider,t.opacity.picker],["mousedown","touchstart"],(()=>this._recalc=!0),{passive:!0})];if(!e.showAlways){const n=e.closeWithKey;o.push(i(t.button,"click",(()=>this.isOpen()?this.hide():this.show())),i(document,"keyup",(t=>this.isOpen()&&(t.key===n||t.code===n)&&this.hide())),i(document,["touchstart","mousedown"],(e=>{this.isOpen()&&!l(e).some((e=>e===t.app||e===t.button))&&this.hide()}),{capture:!0}))}if(e.adjustableNumbers){const e={rgba:[255,255,255,1],hsva:[360,100,100,1],hsla:[360,100,100,1],cmyk:[100,100,100,100]};p(t.interaction.result,((t,o,n)=>{const i=e[this.getColorRepresentation().toLowerCase()];if(i){const e=i[n],s=t+(e>=100?1e3*o:o);return s<=0?0:Number((s<e?s:e).toPrecision(3))}return t}))}if(e.autoReposition&&!e.inline){let t=null;const n=this;o.push(i(window,["scroll","resize"],(()=>{n.isOpen()&&(e.closeOnScroll&&n.hide(),null===t?(t=setTimeout((()=>t=null),100),requestAnimationFrame((function e(){n._rePositioningPicker(),null!==t&&requestAnimationFrame(e)}))):(clearTimeout(t),t=setTimeout((()=>t=null),100)))}),{capture:!0}))}this._eventBindings=o}_rePositioningPicker(){const{options:t}=this;if(!t.inline){if(!this._nanopop.update({container:document.body.getBoundingClientRect(),position:t.position})){const t=this._root.app,e=t.getBoundingClientRect();t.style.top=(window.innerHeight-e.height)/2+"px",t.style.left=(window.innerWidth-e.width)/2+"px"}}}_updateOutput(t){const{_root:e,_color:o,options:n}=this;if(e.interaction.type()){const t=`to${e.interaction.type().getAttribute("data-type")}`;e.interaction.result.value="function"==typeof o[t]?o[t]().toString(n.outputPrecision):""}!this._initializingActive&&this._recalc&&this._emit("change",o,t,this)}_clearColor(t=!1){const{_root:e,options:o}=this;o.useAsButton||e.button.style.setProperty("--pcr-color","rgba(0, 0, 0, 0.15)"),e.button.classList.add("clear"),o.showAlways||this.hide(),this._lastColor=null,this._initializingActive||t||(this._emit("save",null),this._emit("clear"))}_parseLocalColor(t){const{values:e,type:o,a:n}=w(t),{lockOpacity:i}=this.options,s=void 0!==n&&1!==n;return e&&3===e.length&&(e[3]=void 0),{values:!e||i&&s?null:e,type:o}}_t(t){return this.options.i18n[t]||L.I18N_DEFAULTS[t]}_emit(t,...e){this._eventListener[t].forEach((t=>t(...e,this)))}on(t,e){return this._eventListener[t].push(e),this}off(t,e){const o=this._eventListener[t]||[],n=o.indexOf(e);return~n&&o.splice(n,1),this}addSwatch(t){const{values:e}=this._parseLocalColor(t);if(e){const{_swatchColors:t,_root:o}=this,n=A(...e),s=r(`<button type="button" style="--pcr-color: ${n.toRGBA().toString(0)}" aria-label="${this._t("btn:swatch")}"/>`);return o.swatches.appendChild(s),t.push({el:s,color:n}),this._eventBindings.push(i(s,"click",(()=>{this.setHSVA(...n.toHSVA(),!0),this._emit("swatchselect",n),this._emit("change",n,"swatch",this)}))),!0}return!1}removeSwatch(t){const e=this._swatchColors[t];if(e){const{el:o}=e;return this._root.swatches.removeChild(o),this._swatchColors.splice(t,1),!0}return!1}applyColor(t=!1){const{preview:e,button:o}=this._root,n=this._color.toRGBA().toString(0);return e.lastColor.style.setProperty("--pcr-color",n),this.options.useAsButton||o.style.setProperty("--pcr-color",n),o.classList.remove("clear"),this._lastColor=this._color.clone(),this._initializingActive||t||this._emit("save",this._color),this}destroy(){cancelAnimationFrame(this._setupAnimationFrame),this._eventBindings.forEach((t=>s(...t))),Object.keys(this._components).forEach((t=>this._components[t].destroy()))}destroyAndRemove(){this.destroy();const{root:t,app:e}=this._root;t.parentElement&&t.parentElement.removeChild(t),e.parentElement.removeChild(e),Object.keys(this).forEach((t=>this[t]=null))}hide(){return!!this.isOpen()&&(this._root.app.classList.remove("visible"),this._emit("hide"),!0)}show(){return!this.options.disabled&&!this.isOpen()&&(this._root.app.classList.add("visible"),this._rePositioningPicker(),this._emit("show",this._color),this)}isOpen(){return this._root.app.classList.contains("visible")}setHSVA(t=360,e=0,o=0,n=1,i=!1){const s=this._recalc;if(this._recalc=!1,t<0||t>360||e<0||e>100||o<0||o>100||n<0||n>1)return!1;this._color=A(t,e,o,n);const{hue:r,opacity:a,palette:l}=this._components;return r.update(t/360),a.update(n),l.update(e/100,1-o/100),i||this.applyColor(),s&&this._updateOutput(),this._recalc=s,!0}setColor(t,e=!1){if(null===t)return this._clearColor(e),!0;const{values:o,type:n}=this._parseLocalColor(t);if(o){const t=n.toUpperCase(),{options:i}=this._root.interaction,s=i.find((e=>e.getAttribute("data-type")===t));if(s&&!s.hidden)for(const t of i)t.classList[t===s?"add":"remove"]("active");return!!this.setHSVA(...o,e)&&this.setColorRepresentation(t)}return!1}setColorRepresentation(t){return t=t.toUpperCase(),!!this._root.interaction.options.find((e=>e.getAttribute("data-type").startsWith(t)&&!e.click()))}getColorRepresentation(){return this._representation}getColor(){return this._color}getSelectedColor(){return this._lastColor}getRoot(){return this._root}disable(){return this.hide(),this.options.disabled=!0,this._root.button.classList.add("disabled"),this}enable(){return this.options.disabled=!1,this._root.button.classList.remove("disabled"),this}}return E(L,"utils",o),E(L,"version","1.8.2"),E(L,"I18N_DEFAULTS",{"ui:dialog":"color picker dialog","btn:toggle":"toggle color picker dialog","btn:swatch":"color swatch","btn:last-color":"use previous color","btn:save":"Save","btn:cancel":"Cancel","btn:clear":"Clear","aria:btn:save":"save and close","aria:btn:cancel":"cancel and close","aria:btn:clear":"clear and close","aria:input":"color input field","aria:palette":"color selection area","aria:hue":"hue selection slider","aria:opacity":"selection slider"}),E(L,"DEFAULT_OPTIONS",{appClass:null,theme:"classic",useAsButton:!1,padding:8,disabled:!1,comparison:!0,closeOnScroll:!1,outputPrecision:0,lockOpacity:!1,autoReposition:!0,container:"body",components:{interaction:{}},i18n:{},swatches:null,inline:!1,sliders:null,default:"#42445a",defaultRepresentation:null,position:"bottom-middle",adjustableNumbers:!0,showAlways:!1,closeWithKey:"Escape"}),E(L,"create",(t=>new L(t))),e=e.default})()}));
const app_title='GyverHub';const non_esp='';const non_app='__APP__';const app_version='0.51.25b';const hub=new GyverHub();const langs={English:0,Russian:1,};const colors={ORANGE:0xd55f30,YELLOW:0xd69d27,GREEN:0x37A93C,MINT:0x25b18f,AQUA:0x2ba1cd,BLUE:0x297bcd,VIOLET:0x825ae7,PINK:0xc8589a,};const fonts=['monospace','system-ui','cursive','Arial','Verdana','Tahoma','Trebuchet MS','Georgia','Garamond',];const themes={DARK:0,LIGHT:1};const baudrates=[4800,9600,19200,38400,57600,74880,115200,230400,250000,500000,1000000,2000000];const theme_cols=[['#1b1c20','#26272c','#eee','#ccc','#141516','#444','#0e0e0e','dark','#222','#000'],['#eee','#fff','#111','#333','#ddd','#999','#bdbdbd','light','#fff','#000000a3']];function getError(code){return lang[cfg.lang].errors[code];}
let deferredPrompt=null;let screen='main';let focused=null;let cfg_changed=false;let cfg={serial_offset:2000,use_pin:false,pin:'',theme:'DARK',maincolor:'GREEN',font:'monospace',check_upd:true,ui_width:450,lang:'English',app_plugin_css:'',app_plugin_js:'',api_ver:1,};function isSSL(){return window.location.protocol=='https:';}
function isLocal(){return window_ip()!='127.0.0.1'&&(window.location.href.startsWith('file')||checkIP(window_ip())||window_ip()=='localhost');}
function isApp(){return!non_app;}
function isPWA(){return(window.matchMedia('(display-mode: standalone)').matches)||(window.navigator.standalone)||document.referrer.includes('android-app://');}
function isESP(){return!non_esp;}
function isTouch(){return navigator.maxTouchPoints||'ontouchstart'in document.documentElement;}
function hasSerial(){return("serial"in navigator)||isApp();}
function hasBT(){return("bluetooth"in navigator)||isApp();}
function addDOM(el_id,tag,text,target){if(EL(el_id))EL(el_id).remove();let el=document.createElement(tag);el.textContent=text;el.id=el_id;target.appendChild(el);return el;}
function getErrColor(){return'#8e1414';}
function getDefColor(){return intToCol(colors[cfg.maincolor]);}
function dataTotext(data){return b64ToText(data.split('base64,')[1]);}
function b64ToText(base64){const binString=atob(base64);return new TextDecoder().decode(Uint8Array.from(binString,(m)=>m.codePointAt(0)));}
function confirmDialog(msg){return new Promise(function(resolve,reject){let confirmed=window.confirm(msg);return confirmed?resolve(true):reject(false);});}
String.prototype.hashCode=function(){if(!this.length)return 0;let hash=new Uint32Array(1);for(let i=0;i<this.length;i++){hash[0]=((hash[0]<<5)-hash[0])+this.charCodeAt(i);}
return hash[0];}
function getMime(name){const mime_table={'avi':'video/x-msvideo','bin':'application/octet-stream','bmp':'image/bmp','css':'text/css','csv':'text/csv','gz':'application/gzip','gif':'image/gif','html':'text/html','jpeg':'image/jpeg','jpg':'image/jpeg','js':'text/javascript','json':'application/json','png':'image/png','svg':'image/svg+xml','txt':'text/plain','wav':'audio/wav','xml':'application/xml',};let ext=name.split('.').pop();if(ext in mime_table)return mime_table[ext];else return'text/plain';}
function openURL(url){window.open(url,'_blank').focus();}
function intToCol(val){if(val===null||val===undefined)return null;return"#"+Number(val).toString(16).padStart(6,'0');}
function intToColA(val){if(val===null||val===undefined)return null;return"#"+Number(val).toString(16).padStart(8,'0');}
function constrain(val,min,max){return val<min?min:(val>max?max:val);}
function colToInt(str){return parseInt(str.substr(1),16);}
function adjustColor(col,ratio){let intcol=0;col=col.toString();if(col.startsWith('#')){col=col.slice(1);if(col.length==3){col=col[0]+col[0]+col[1]+col[1]+col[2]+col[2];}
intcol=parseInt(col,16);}else if(col.startsWith("rgb(")){col.replace("rgb(","").replace(")","").replace(" ","").split(',').forEach(v=>intcol=(intcol<<8)|v);}else{intcol=Number(col);}
let newcol='#';for(let i=0;i<3;i++){let comp=(intcol&0xff0000)>>16;comp=Math.min(255,Math.floor((comp+1)*ratio));newcol+=comp.toString(16).padStart(2,'0');intcol<<=8;}
return newcol;}
function crc32(data){let crc=new Uint32Array(1);crc[0]=0;crc[0]=~crc[0];let str=(typeof(data)=='string');for(let i=0;i<data.length;i++){crc[0]^=str?data[i].charCodeAt(0):data[i];for(let i=0;i<8;i++)crc[0]=(crc[0]&1)?((crc[0]/2)^0x4C11DB7):(crc[0]/2);}
crc[0]=~crc[0];return crc[0];}
function random(min,max){return Math.floor(Math.random()*(max-min+1)+min)}
function parseCSV(str){const arr=[];let quote=false;for(let row=0,col=0,c=0;c<str.length;c++){let cc=str[c],nc=str[c+1];arr[row]=arr[row]||[];arr[row][col]=arr[row][col]||'';if(cc=='"'&&quote&&nc=='"'){arr[row][col]+=cc;++c;continue;}
if(cc=='"'){quote=!quote;continue;}
if(cc==';'&&!quote){++col;continue;}
if(cc=='\r'&&nc=='\n'&&!quote){++row;col=0;++c;continue;}
if(cc=='\n'&&!quote){++row;col=0;continue;}
if(cc=='\r'&&!quote){++row;col=0;continue;}
arr[row][col]+=cc;}
return arr;}
function openFile(src){let w=window.open();src=w.document.write('<iframe src="'+src+'" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>');}
async function copyClip(text){try{await navigator.clipboard.writeText(text);showPopup('Copied to clipboard');}catch(e){showPopupError('Error');}}
function getIcon(icon){if(!icon)return'';return icon.length==1?icon:String.fromCharCode(Number('0x'+icon));}
function notSupported(){alert('Browser is not supported');}
function browser(){if(navigator.userAgent.includes("Opera")||navigator.userAgent.includes('OPR'))return'opera';else if(navigator.userAgent.includes("Edg"))return'edge';else if(navigator.userAgent.includes("Chrome"))return'chrome';else if(navigator.userAgent.includes("Safari"))return'safari';else if(navigator.userAgent.includes("Firefox"))return'firefox';else if((navigator.userAgent.includes("MSIE"))||(!!document.documentMode==true))return'IE';else return'unknown';}
function ratio(){return window.devicePixelRatio;}
function sleep(ms){return new Promise(resolve=>setTimeout(resolve,ms));}
function EL(id){return document.getElementById(id);}
function ID(id){return'__'+id;}
function CMP(id){return EL(ID(id));}
function display(id,value){EL(id).style.display=value;}
function getUnix(arg){return Math.floor(arg.valueAsNumber/1000);}
function showNotif(name,text){if(!("Notification"in window)||Notification.permission!='granted')return;let descr=name+' ('+new Date(Date.now()).toLocaleString()+')';navigator.serviceWorker.getRegistration().then(function(reg){reg.showNotification(text,{body:descr,vibrate:true});}).catch(e=>console.log(e));}
function waitFrame(){return new Promise(requestAnimationFrame);}
async function waitRender(id){while(true){if(EL(id))return Promise.resolve(1);await waitFrame();}}
function window_ip(){let ip=window.location.href.split('/')[2].split(':')[0];return checkIP(ip)?ip:null;}
function getMaskList(){let list=[];for(let i=0;i<33;i++){let imask;if(i==32)imask=0xffffffff;else imask=~(0xffffffff>>>i);list.push(`${(imask >>> 24) & 0xff}.${(imask >>> 16) & 0xff}.${(imask >>> 8) & 0xff}.${imask & 0xff}`);}
return list;}
class UiRender{contIdx=0;prevWidth=1;dup_names='';root=null;reset(){this.contIdx=0;this.prevWidth=1;this.dup_names='';}
render(cont,type,data,single){let non_widgets=['menu','dummy','js','css','confirm','prompt','plugin','hook','ui_file'];switch(type){case'row':let sumw=0;for(let ctrl of data){if(!ctrl.type||non_widgets.includes(ctrl.type))continue;if(!ctrl.wwidth)ctrl.wwidth=this.prevWidth;else this.prevWidth=ctrl.wwidth;sumw+=ctrl.wwidth;}
for(let ctrl of data){if(!ctrl.type||non_widgets.includes(ctrl.type))continue;ctrl.wwidth_t=ctrl.wwidth*100/sumw;}
break;case'col':for(let ctrl of data){if(!ctrl.type||non_widgets.includes(ctrl.type))continue;ctrl.wwidth_t=100;}
break;}
for(let ctrl of data){if(!ctrl.type)continue;if(ctrl.type=='hook'){UiHook.add(ctrl.id,ctrl.value);continue;}
if(ctrl.type=='row'||ctrl.type=='col'){if(single){this.render(cont,'col',ctrl.data,single);}else{this.contIdx++;let newCont='container#'+this.contIdx;cont.innerHTML+=`<div class="${'widget_' + ctrl.type}" id="${newCont}" style="width:${ctrl.wwidth_t}%"></div>`;this.render(EL(newCont),ctrl.type,ctrl.data,single);}}else{if(ctrl.id&&CMP(ctrl.id)){if(this.dup_names.length)this.dup_names+=', ';this.dup_names+=ctrl.id;continue;}
switch(ctrl.type){case'space':ctrl.nolabel=1;ctrl.notab=1;break;case'title':ctrl.nolabel=1;ctrl.notab=1;ctrl.square=0;break;case'menu':Menu.add(ctrl);continue;case'ui_file':new UiFile(cont,ctrl,type,single);continue;case'dummy':continue;case'js':new UiJS(this.root,ctrl);continue;case'css':new UiCSS(this.root,ctrl);continue;case'confirm':new UiConfirm(cont,ctrl);continue;case'prompt':new UiPrompt(cont,ctrl);continue;case'plugin':new UiPlugin(this.root,ctrl,focused);continue;default:break;}
let wid=new Widget(cont,ctrl,ctrl.wwidth_t);switch(ctrl.type){case'input':new UiInput(wid,ctrl);break;case'pass':new UiPass(wid,ctrl);break;case'area':new UiArea(wid,ctrl);break;case'button':new UiButton(wid,ctrl);break;case'switch':new UiSwitch(wid,ctrl);break;case'swicon':new UiSwicon(wid,ctrl);break;case'title':new UiTitle(wid,ctrl);break;case'label':new UiLabel(wid,ctrl);break;case'text':new UiText(wid,ctrl);break;case'text_f':new UiText_f(wid,ctrl);break;case'display':new UiDisplay(wid,ctrl);break;case'image':new UiImage(wid,ctrl);break;case'table':new UiTable(wid,ctrl);break;case'log':new UiLog(wid,ctrl);break;case'date':new UiDate(wid,ctrl);break;case'time':new UiTime(wid,ctrl);break;case'datetime':new UiDateTime(wid,ctrl);break;case'slider':new UiSlider(wid,ctrl);break;case'spinner':new UiSpinner(wid,ctrl);break;case'select':new UiSelect(wid,ctrl);break;case'color':new UiColor(wid,ctrl);break;case'led':new UiLED(wid,ctrl);break;case'html':new UiHTML(wid,ctrl);break;case'func':new UiFunc(focused,wid,ctrl);break;case'gauge':new UiGauge(wid,ctrl);break;case'gauge_r':new UiGaugeR(wid,ctrl);break;case'joy':new UiJoy(wid,ctrl);break;case'dpad':new UiDpad(wid,ctrl);break;case'flags':new UiFlags(wid,ctrl);break;case'tabs':new UiTabs(wid,ctrl);break;case'canvas':new UiCanvas(wid,ctrl);break;case'stream':new UiStream(wid,ctrl);break;default:break;}}}}}
class Menu{static add(ctrl){let inner='';let labels=[];if(ctrl!=null&&ctrl.text){labels=ctrl.text.toString().split(';');for(let i in labels){let sel=(i==ctrl.value)?'menu_act':'';inner+=`<div onclick="Menu.click(${i})" class="menu_item ${sel}">${labels[i].trim()}</div>`;}}
EL('menu_user').innerHTML=inner;EL('menu_system').innerHTML='<div id="menu_info" class="menu_item" onclick="info_h()">Info</div>';let count=1;let dev=hub.dev(focused);if(dev.module(Modules.FILES)){count++;EL('menu_system').innerHTML+='<div id="menu_fsbr" class="menu_item" onclick="fsbr_h()">Files</div>';}
if(dev.module(Modules.OTA)||dev.module(Modules.OTA_URL)){count++;EL('menu_system').innerHTML+='<div id="menu_ota" class="menu_item" onclick="ota_h()">OTA</div>';}
document.querySelector(':root').style.setProperty('--menu_h',((labels.length+count)*35+10)+'px');}
static clear(){Menu.add(null);}
static click(num){try{hub.dev(focused).fsStop();}catch(e){}
menu_show(0);Menu.deact();if(screen!='ui')show_screen('ui');post_set('_menu',num);}
static deact(){let els=Array.from(document.getElementById('menu_user').children).filter(el=>el.tagName=='DIV');els.push(EL('menu_info'),EL('menu_fsbr'),EL('menu_ota'));for(let el in els)if(els[el])els[el].classList.remove('menu_act');}};
class Widget{constructor(cont,ctrl,width){let hint='ID: '+ctrl.id+'\n'+(ctrl.hint??'');cont.innerHTML+=`
<div id="widget_main#${ctrl.id}" class="widget_main ${ctrl.square ? 'wsquare' : ''}" style="width:${width}%">
<div id="widget_inner#${ctrl.id}" class="widget_inner ${(ctrl.notab && ctrl.notab == 1) ? 'widget_notab' : ''}">
<div id="wlabel_cont#${ctrl.id}" class="widget_label ${ctrl.nolabel ? 'wnolabel' : ''}">
<span id="wlabel#${ctrl.id}" title="${hint}" onclick="alert(this.title)">${(ctrl.label && ctrl.label.length) ? ctrl.label : ctrl.type}</span>
<span id="plabel#${ctrl.id}" class="plabel"></span>
<span id="wsuffix#${ctrl.id}" class="wsuffix">${ctrl.suffix ?? ''}</span>
</div>
<div id=widget#${ctrl.id} class="widget_body ${ctrl.dsbl ? 'widget_dsbl' : ''}" style="${(ctrl.wheight && ctrl.wheight > 25) ? ('min-height:' + ctrl.wheight + 'px') : ''}"></div>
</div>
</div>
`;return EL('widget#'+ctrl.id);}
static update(name,type,data){if('label'in data){EL('wlabel#'+name).innerHTML=data.label.length?data.label:type;}
if('suffix'in data){EL('wsuffix#'+name).innerHTML=data.suffix;}
if('nolabel'in data){if(data.nolabel)EL('wlabel_cont#'+name).classList.add('wnolabel');else EL('wlabel_cont#'+name).classList.remove('wnolabel');}
if('square'in data){if(data.square)EL('widget_main#'+name).classList.add('wsquare');else EL('widget_main#'+name).classList.remove('wsquare');}
if('notab'in data){if(data.notab)EL('widget_inner#'+name).classList.add('widget_notab');else EL('widget_inner#'+name).classList.remove('widget_notab');}
if('dsbl'in data){if(data.dsbl)EL('widget#'+name).classList.add('widget_dsbl');else EL('widget#'+name).classList.remove('widget_dsbl');}
if('hint'in data){EL('wlabel#'+name).title='ID: '+name+'\n'+data.hint;}}
static disable(id,dsbl){let el=CMP(id);if(dsbl){el.setAttribute('disabled','1');el.classList.add('dsbl');}else{el.removeAttribute('disabled');el.classList.remove('dsbl');}}
static align(id,align){EL('widget#'+id).style.justifyContent=["flex-start","center","flex-end"][Number(align??1)];}};
class UiButton{constructor(cont,data){cont.innerHTML=`<button data-type="${data.type}" id="${ID(data.id)}" style="font-size:${data.fsize ?? 45}px;color:${intToCol(data.color) ?? 'var(--prim)'}" class="icon w_btn" onclick="post_set('${data.id}',2)" onmousedown="if(!UiButton.touch)post_click('${data.id}',1)" onmouseup="if(!UiButton.touch&&UiButton.pressID)post_click('${data.id}',0)" onmouseleave="if(UiButton.pressID&&!UiButton.touch)post_click('${data.id}',0);" ontouchstart="UiButton.touch=1;post_click('${data.id}',1)" ontouchend="post_click('${data.id}',0)" data-color="${intToCol(data.color) ?? 'var(--prim)'}" data-size="${data.fsize ?? 45}px"></button>`;UiButton.setIcon(data.id,data.text);Widget.disable(data.id,data.dsbl);}
static update(id,data){let el=CMP(id);if('text'in data){UiButton.setIcon(id,data.text);}
if('color'in data){let col=intToCol(data.color);el.style.color=col;el.style.fill=col;el.setAttribute("data-color",col);}
if('fsize'in data){let size=data.fsize+'px';el.style.fontSize=size;if(!el.getAttribute("data-inline"))el.style.width=size;else el.style.width='unset';el.setAttribute("data-size",size);}
if('dsbl'in data){Widget.disable(id,data.dsbl);}}
static apply(id,icon){let el=CMP(id);el.innerHTML=icon;el.style.width=el.getAttribute("data-size");el.style.fill=el.getAttribute("data-color");}
static setIcon(id,text){let el=CMP(id);if(!el)return;let icon="";el.style.width='unset';if(text){if(text.includes(".svg")){hub.dev(focused).addFile(id,text,{type:"icon"});el.removeAttribute("data-inline");return;}else{icon=getIcon(text);}}
el.innerHTML=icon;el.setAttribute("data-inline",true);}
static pressID=null;static touch=0;};
class UiLabel{constructor(cont,data){cont.innerHTML=`<div id=lbl_cont#${data.id} class='w_label' style="color:${intToCol(data.color) ?? 'unset'};font-size:${data.fsize ?? 35}px"><span id="lbl_icon#${data.id}" class="w_icon">${data.text ? (getIcon(data.text) + ' ') : ''}</span><label data-type="${data.type}" id='${ID(data.id)}'>${data.value ?? ''}</label></div>`;Widget.align(data.id,data.align);}
static update(id,data){let el=CMP(id);let cont=EL('lbl_cont#'+id);if('value'in data)el.innerHTML=data.value;if('color'in data)cont.style.color=intToCol(data.color);if('fsize'in data)cont.style.fontSize=data.fsize+'px';if('align'in data)Widget.align(id,data.align);if('text'in data){EL('lbl_icon#'+id).innerHTML=data.text?(getIcon(data.text)+' '):'';}}};
class UiTitle{constructor(cont,data){cont.innerHTML=`<div id=lbl_cont#${data.id} class='w_label' style="color:${intToCol(data.color) ?? 'unset'};font-size:${data.fsize ?? 35}px"><span id="lbl_icon#${data.id}" class="w_icon">${data.text ? (getIcon(data.text) + ' ') : ''}</span><label data-type="${data.type}" id='${ID(data.id)}'>${data.value ?? ''}</label></div>`;Widget.align(data.id,data.align);}
static update(id,data){let el=CMP(id);let cont=EL('lbl_cont#'+id);if('value'in data)el.innerHTML=data.value;if('color'in data)cont.style.color=intToCol(data.color);if('fsize'in data)cont.style.fontSize=data.fsize+'px';if('align'in data)Widget.align(id,data.align);if('text'in data){EL('lbl_icon#'+id).innerHTML=data.text?(getIcon(data.text)+' '):'';}}};
class UiPlugin{constructor(cont,data,dev_id){if(data.js&&data.js.length&&!EL(dev_id+'_script')){if(data.js.endsWith('.js')){hub.dev(dev_id).addFile('_script',data.js,{type:"plugin_js",cont:cont});}else{UiPlugin.applyScript(dev_id,data.js);}}
if(data.css&&data.css.length&&!EL(dev_id+'_style')){if(data.css.endsWith('.css')){hub.dev(dev_id).addFile('_style',data.css,{type:"plugin_css"});}else{UiPlugin.applyStyle(dev_id,data.css);}}}
static applyScript(dev_id,text){addDOM(dev_id+'_script','script',text.replaceAll('function ','function '+dev_id+'_'),document.body);}
static applyStyle(dev_id,text){addDOM(dev_id+'_style','style',text,document.body);}
static enableStyle(dev_id){let el=EL(dev_id+'_style');if(el)el.disabled=false;}
static disableStyle(dev_id){let el=EL(dev_id+'_style');if(el)el.disabled=true;}};
class UiSwitch{constructor(cont,data){cont.innerHTML=`
<style id="style#${data.id}"></style>
<label id="swlabel_${data.id}" class="switch"><input type="checkbox" data-type="${data.type}" id='${ID(data.id)}' onclick="post_set('${data.id}',(this.checked ? 1 : 0))" ${data.value == '1' ? 'checked' : ''}><span class="slider"></span></label>`;UiSwitch.color(data.id,data.color);Widget.disable(data.id,data.dsbl);}
static update(id,data){let el=CMP(id);if('value'in data)el.checked=(Number(data.value)==1);if('color'in data)UiSwitch.color(id,data.color);if('dsbl'in data)Widget.disable(id,data.dsbl);}
static color(id,color){if(color){EL('style#'+id).innerHTML=`#swlabel_${id} input:checked+.slider{background:${intToCol(color) ?? 'var(--prim)'}`;}}};
class UiSwicon{constructor(cont,data){cont.innerHTML=`
<style id="style#${data.id}"></style>
<div data-type="${data.type}" id="${ID(data.id)}" style="font-size:${data.fsize ?? 45}px;width:${data.fsize ? data.fsize * 1.8 : 80}px" class="icon icon_btn_big w_swicon ${data.value == '1' ? 'w_swicon_on' : ''}" onclick="UiSwicon.click('${data.id}')">${data.text ? getIcon(data.text) : ''}</div>`;UiSwicon.color(data.id,intToCol(data.color)??getDefColor());Widget.disable(data.id,data.dsbl);}
static update(id,data){let el=CMP(id);if('value'in data){if(Number(data.value)==1)el.classList.add('w_swicon_on');else el.classList.remove('w_swicon_on');}
if('fsize'in data){el.style.fontSize=data.fsize+'px';el.style.width=data.fsize*1.8+'px';}
if('text'in data)el.innerHTML=getIcon(data.text);if('color'in data)UiSwicon.color(id,intToCol(data.color));if('dsbl'in data)Widget.disable(id,data.dsbl);}
static click(id){let el=CMP(id);if(el.getAttribute('disabled'))return;el.classList.toggle('w_swicon_on');post_set(id,(el.classList.contains('w_swicon_on')?1:0));}
static color(id,color){if(color){EL('style#'+id).innerHTML=`
#${ID(id)}.w_swicon {
color: ${color};
border: 2px solid ${color};
}
#${ID(id)}.w_swicon_on {
color: var(--tab);
background: ${color};
`;}}};
class UiDisplay{constructor(cont,data){cont.innerHTML=`<textarea data-type="${data.type}" id="${ID(data.id)}" onwheel="UiDisplay.wheel(event,this)" class="w_disp" style="font-size:${data.fsize ?? 20}px;background:${intToCol(data.color) ?? 'var(--prim)'}" rows="${data.rows ?? 2}" readonly>${data.value ?? ''}</textarea>`;}
static update(id,data){let el=CMP(id);if('value'in data)el.innerHTML=data.value;if('color'in data)el.style.background=intToCol(data.color);if('fsize'in data)el.style.fontSize=data.fsize+'px';if('rows'in data)el.rows=data.rows;}
static wheel(e,el){e.preventDefault();el.scrollLeft+=e.deltaY;}};
class UiImage{constructor(cont,data){cont.innerHTML=`<div data-type="${data.type}" data-path="${data.value ?? ''}" id="${ID(data.id)}">${waiter()}</div>`;if(data.value)hub.dev(focused).addFile(data.id,data.value,{type:"img"});}
static update(id,data){let el=CMP(id);if('value'in data){hub.dev(focused).addFile(id,data.value,{type:"img"});el.setAttribute("data-path",data.value);}
if('action'in data){hub.dev(focused).addFile(id,el.getAttribute("data-path"),{type:"img"});}}
static apply(id,file){CMP(id).innerHTML=`<img style="width:100%" src="${file}">`;}};
class UiTable{constructor(cont,data){if(!data.value)data.value='';let isFile=(!data.value.includes(';')&&data.value.endsWith(".csv"));cont.innerHTML=`<div data-type="${data.type}" data-align="${data.align ?? ''}" data-width="${data.width ?? ''}" id="${ID(data.id)}" style="display:contents" data-path="${isFile ? data.value : ''}" data-csv="${isFile ? '' : data.value}"></div>`;if(isFile){hub.dev(focused).addFile(data.id,data.value,{type:"csv"});CMP(data.id).innerHTML=waiter();}else{UiTable.render(data.id);}}
static update(id,data){let el=CMP(id);if('action'in data){hub.dev(focused).addFile(id,el.getAttribute("data-path"),{type:"csv"});}
if('value'in data){let val=data.value;if(!val.includes(';')&&val.endsWith(".csv")){hub.dev(focused).addFile(id,val,{type:"csv"});el.setAttribute("data-path",val);}else{el.setAttribute("data-csv",val);UiTable.render(id);}}
if('align'in data){el.setAttribute("data-align",data.align);UiTable.render(id);}
if('width'in data){el.setAttribute("data-width",data.width);UiTable.render(id);}}
static apply(id,csv){CMP(id).setAttribute("data-csv",csv);UiTable.render(id);}
static async render(id){let el=CMP(id);let aligns=el.getAttribute("data-align").split(';');let widths=el.getAttribute("data-width").split(';');let table=parseCSV(el.getAttribute("data-csv"));let inner=`<table class="w_table">`;for(let row of table){inner+='<tr>';for(let col in row){inner+=`<td width="${widths[col] ? (widths[col] + '%') : ''}" align="${aligns[col] ? aligns[col] : 'center'}">${row[col]}</td>`;}
inner+='</tr>';}
inner+='</table>';el.innerHTML=inner;}};
class UiDate{constructor(cont,data){let date=new Date((data.value??0)*1000).toISOString().split('T')[0];cont.innerHTML=`<input data-type="${data.type}" id='${ID(data.id)}' class="w_date" style="color:${intToCol(data.color) ?? 'var(--prim)'}" type="date" value="${date}" onclick="this.showPicker()" onchange="post_set('${data.id}',getUnix(this))">`;Widget.disable(data.id,data.dsbl);}
static update(id,data){let el=CMP(id);if('value'in data)el.value=new Date(data.value*1000).toISOString().split('T')[0];if('color'in data)el.style.color=intToCol(data.color);}};class UiTime{constructor(cont,data){let time=new Date((data.value??0)*1000).toISOString().split('T')[1].split('.')[0];cont.innerHTML=`<input data-type="${data.type}" id='${ID(data.id)}' class="w_date" style="color:${intToCol(data.color) ?? 'var(--prim)'}" type="time" value="${time}" onclick="this.showPicker()" onchange="post_set('${data.id}',getUnix(this))" step="1">`;Widget.disable(data.id,data.dsbl);}
static update(id,data){let el=CMP(id);if('value'in data)el.value=new Date(data.value*1000).toISOString().split('T')[1].split('.')[0];if('color'in data)el.style.color=intToCol(data.color);}};class UiDateTime{constructor(cont,data){let datetime=new Date((data.value??0)*1000).toISOString().split('.')[0];cont.innerHTML=`<input data-type="${data.type}" id='${ID(data.id)}' class="w_date" style="color:${intToCol(data.color) ?? 'var(--prim)'}" type="datetime-local" value="${datetime}" onclick="this.showPicker()" onchange="post_set('${data.id}',getUnix(this))" step="1">`;Widget.disable(data.id,data.dsbl);}
static update(id,data){let el=CMP(id);if('value'in data)el.value=new Date(data.value*1000).toISOString().split('.')[0];if('color'in data)el.style.color=intToCol(data.color);}};
class UiConfirm{constructor(cont,data){cont.innerHTML+=`<div id="widget#${data.id}" style="display:none"><div data-type="${data.type}" id="${ID(data.id)}" data-text="${data.text ?? 'No text'}"></div></div>`;}
static update(id,data){let el=CMP(id);if('action'in data){release_all();let res=confirm(el.getAttribute("data-text"));post_set(id,res?1:0);}
if('text'in data){el.setAttribute("data-text",data.text);}}};class UiPrompt{constructor(cont,data){cont.innerHTML+=`<div id="widget#${data.id}" style="display:none"><div data-type="${data.type}" id="${ID(data.id)}" data-text="${data.text ?? 'No text'}" data-value="${data.value ?? ''}"></div></div>`;}
static update(id,data){let el=CMP(id);if('action'in data){release_all();let res=prompt(el.getAttribute("data-text"),el.getAttribute("data-value"));if(res!==null){el.setAttribute("data-value",res);post_set(id,res);}}
if('value'in data){el.setAttribute("data-value",data.value);}
if('text'in data){el.setAttribute("data-text",data.text);}}};
class UiLog{constructor(cont,data){cont.innerHTML=`<textarea data-type="${data.type}" id="${ID(data.id)}" style="color:var(--prim)" class="w_area w_area_passive" rows="${data.rows ?? 5}" readonly>${data.value ? data.value.trim() : ''}</textarea>`;waitFrame().then(()=>CMP(data.id).scrollTop=CMP(data.id).scrollHeight);}
static update(id,data){let el=CMP(id);if('value'in data){el.innerHTML=data.value.trim();el.scrollTop=el.scrollHeight;}
if('rows'in data){el.rows=data.rows;}}};
class UiText{constructor(cont,data){cont.innerHTML=`<textarea data-type="${data.type}" id="${ID(data.id)}" class="w_area w_area_passive" rows="${data.rows ?? 5}" readonly>${data.value ?? ''}</textarea>`;}
static update(id,data){let el=CMP(id);if('value'in data)el.innerHTML=data.value;if('rows'in data)el.rows=data.rows;}};class UiText_f{constructor(cont,data){cont.innerHTML=`<textarea data-type="${data.type}" id="${ID(data.id)}" data-path="${data.value ?? ''}" class="w_area w_area_passive" rows="${data.rows ?? 5}" readonly></textarea>`;if(data.value)hub.dev(focused).addFile(data.id,data.value,{type:"text"});}
static update(id,data){let el=CMP(id);if('action'in data){hub.dev(focused).addFile(id,el.getAttribute("data-path"),{type:"text"});}
if('value'in data){hub.dev(focused).addFile(id,data.value,{type:"text"});el.setAttribute("data-path",data.value);}
if('rows'in data){el.rows=data.rows;}}
static apply(id,text){CMP(id).innerHTML=text;}};
class UiInput{constructor(cont,data){cont.innerHTML=`
<div class="w_inp_cont">
<input data-type="${data.type}" class="w_inp" type="text" value="${data.value ?? ''}" id="${ID(data.id)}" name="${data.id}" onkeydown="UiInput.checkDown(this,event)" oninput="UiInput.check(this)" pattern="${data.regex ?? ''}" maxlength="${data.maxlen ?? ''}" onfocusout="UiInput.send(this)">
</div>
`;UiInput.color(data.id,data.color);Widget.disable(data.id,data.dsbl);}
static update(id,data){let el=CMP(id);if('color'in data)UiInput.color(id,data.color);if('value'in data)el.value=data.value;if('regex'in data)el.pattern=data.regex;if('maxlen'in data)el.maxlength=Math.ceil(data.maxlen);if('dsbl'in data)Widget.disable(id,data.dsbl);}
static color(id,color){if(color)CMP(id).style.boxShadow='0px 2px 0px 0px '+intToCol(color);}
static send(arg,force=false){if(arg.pattern){const r=new RegExp(arg.pattern);if(!r.test(arg.value)){showPopupError("Wrong text!");return;}}
if(force||arg.getAttribute('data-changed')){arg.removeAttribute('data-changed');post_set(arg.name,arg.value);}}
static check(arg){setPlabel(arg.name,'•');arg.setAttribute('data-changed','1');}
static checkDown(arg,event){if(event.key=='Enter')UiInput.send(arg,true);}};
class UiPass{constructor(cont,data){cont.innerHTML=`
<div class="w_inp_cont">
<input data-type="${data.type}" class="w_inp" type="password" value="${data.value ?? ''}" id="${ID(data.id)}" name="${data.id}" onkeydown="UiInput.checkDown(this,event)" oninput="UiInput.check(this)" pattern="${data.regex ?? ''}" maxlength="${data.maxlen ?? ''}" onfocusout="UiInput.send(this)">
<div class="btn_inp_block">
<button class="icon w_eye" onclick="UiPass.toggle('${ID(data.id)}')"></button>
</div>
</div>
`;UiInput.color(data.id,data.color);Widget.disable(data.id,data.dsbl);}
static toggle(id){let el=CMP(id);if(el.type=='text')el.type='password';else el.type='text';}
static update(id,data){let el=CMP(id);if('color'in data)UiInput.color(id,data.color);if('value'in data)el.value=data.value;if('regex'in data)el.pattern=data.regex;if('maxlen'in data)el.maxlength=Math.ceil(data.maxlen);if('dsbl'in data)Widget.disable(id,data.dsbl);}}
class UiArea{constructor(cont,data){cont.innerHTML=`<textarea data-type="${data.type}" class="w_area" id="${ID(data.id)}" name="${data.id}" onkeydown="UiInput.checkDown(this,event)" oninput="UiInput.check(this)" pattern="${data.regex ?? ''}" maxlength="${data.maxlen ?? ''}" onfocusout="UiInput.send(this)">${data.value ?? ''}</textarea>`;UiInput.color(ID(data.id),data.color);Widget.disable(data.id,data.dsbl);}
static update(id,data){let el=CMP(id);if('value'in data)el.innerHTML=data.value;if('maxlen'in data)el.maxlength=Math.ceil(data.maxlen);if('rows'in data)el.rows=data.rows;if('dsbl'in data)Widget.disable(id,data.dsbl);}};
class UiSlider{constructor(cont,data){cont.innerHTML=`<input data-type="${data.type}" name="${data.id}" id="${ID(data.id)}" oninput="UiSlider.move(this)" type="range" class="w_slider" value="${data.value ?? 0}" min="${data.min ?? 0}" max="${data.max ?? 100}" step="${data.step ?? 1}" data-dec="${data.dec ?? 0}" data-unit="${data.unit ?? ''}" onwheel="UiSlider.wheel(event,this)">
<div class="w_slider_out"><output id="out#${data.id}"></output></div>`;waitFrame().then(()=>UiSlider.move(CMP(data.id),false));UiSlider.color(data.id,data.color);Widget.disable(data.id,data.dsbl);}
static color(id,color){if(color)CMP(id).style.backgroundImage=`linear-gradient(${intToCol(color)}, ${intToCol(color)})`;}
static update(id,data){let el=CMP(id);if('value'in data)el.value=data.value;if('color'in data)UiSlider.color(id,data.color);if('min'in data)el.min=data.min;if('max'in data)el.max=data.max;if('step'in data)el.step=data.step;if('dec'in data)el.setAttribute("data-dec",data.dec);if('unit'in data)el.setAttribute("data-unit",data.unit);UiSlider.move(el,false);}
static move(el,send=true){el.style.backgroundSize=(Number(el.value)-Number(el.min))*100/(Number(el.max)-Number(el.min))+'% 100%';EL('out#'+el.name).innerHTML=Number(el.value).toFixed(Number(el.getAttribute("data-dec")))+el.getAttribute("data-unit");if(send)post_set_prd(el.name,el.value);}
static wheel(e,el){e.preventDefault();el.value=Number(el.value)-Math.sign(Number(e.deltaY))*Number(el.step);UiSlider.move(el);}}
class UiSpinner{constructor(cont,data){cont.innerHTML=`
<div class="w_spinner_row">
<button class="icon icon_btn btn_no_pad" onclick="UiSpinner.spin('${data.id}',-1)"></button>
<div class="w_spinner_block">
<input data-type="${data.type}" id="${ID(data.id)}" class="w_spinner" type="number" oninput="UiSpinner.input('${data.id}')" onkeydown="UiSpinner.checkDown(event,'${data.id}')" value="${data.value ?? 0}" min="${data.min ?? 0}" max="${data.max ?? 100}" step="${data.step ?? 1}" data-dec="${data.dec ?? 0}" data-unit="${data.unit ?? ''}" onwheel="UiSpinner.wheel(event,'${data.id}')">
<label class="w_spinner_unit" id="unit#${data.id}" onwheel="UiSpinner.wheel(event,'${data.id}')"></label>
</div>
<button class="icon icon_btn btn_no_pad" onclick="UiSpinner.spin('${data.id}',1)"></button>
</div>
`;waitFrame().then(()=>UiSpinner.spin(data.id,0,false));Widget.disable(data.id,data.dsbl);}
static update(id,data){let el=CMP(id);if('value'in data)el.value=data.value;if('min'in data)el.min=data.min;if('max'in data)el.max=data.max;if('step'in data)el.step=data.step;if('dec'in data)el.setAttribute("data-dec",data.dec);if('unit'in data)el.setAttribute("data-unit",data.unit);UiSpinner.spin(id,0,false);}
static spin(id,dir,send=true){let el=CMP(id);if(dir&&el.getAttribute("disabled"))return;let val=Number(el.value)+Number(el.step)*Math.sign(Number(dir));val=Math.max(Number(el.min),val);val=Math.min(Number(el.max),val);el.value=Number(val).toFixed(Number(el.getAttribute("data-dec")));el.style.width=el.value.length+'ch';EL('unit#'+id).innerHTML=el.getAttribute("data-unit");if(send)post_set_prd(id,el.value);}
static input(id){UiSpinner.spin(id,0);}
static wheel(e,id){e.preventDefault();UiSpinner.spin(id,-e.deltaY);}
static checkDown(e,id){if(e.key=='Enter'){e.preventDefault();UiSpinner.spin(id,0);}}};
class UiHTML{constructor(cont,data){if(!data.value)return;if(data.value.endsWith('.html')){hub.dev(focused).addFile(data.id,data.value,{type:"html"});}else{UiHTML.apply(data.id,data.value);cont.setAttribute('data-custom','html');}}
static apply(id,text){EL('widget#'+id).innerHTML=text;}
static update(id,data){if(!data.value)return;if(data.value.endsWith('.html')){hub.dev(focused).addFile(id,data.value,{type:"html"});}else{UiHTML.apply(id,data.value);}}};class UiJS{constructor(cont,data){if(!data.value)return;if(data.value.endsWith('.js')){hub.dev(focused).addFile(data.id,data.value,{type:"js",cont:cont});}else{UiJS.apply(data.id,data.value,cont);}}
static apply(id,text,cont){let el=addDOM('custom_script_'+id,'script',text,cont);el.setAttribute("data-custom-script",true);}
static disable(){document.querySelectorAll('[data-custom-script]').forEach(el=>el.remove());}};class UiCSS{constructor(cont,data){if(!data.value)return;if(data.value.endsWith('.css')){hub.dev(focused).addFile(data.id,data.value,{type:"css",cont:cont});}else{UiCSS.apply(data.id,data.value,cont);}}
static apply(id,text,cont){let el=addDOM('custom_style_'+id,'style',text,cont);el.setAttribute("data-custom-style",true);}
static disable(){document.querySelectorAll('[data-custom-style]').forEach(el=>el.remove());}};
class UiFunc{constructor(dev_id,wid,data){wid.setAttribute("data-defaults",JSON.stringify(data));wid.setAttribute("data-func",dev_id+'_'+data.func);}
static render(cont){cont.querySelectorAll('[data-func]').forEach(wid=>{let func=wid.getAttribute("data-func");if(typeof window[func]!=="function")return;let data=wid.getAttribute("data-defaults");if(!data)return;try{data=JSON.parse(data);}catch(e){console.log("Plugin data error: "+func);return;}
wid.removeAttribute("data-defaults");try{wid.innerHTML=window[func](data.id,data);}catch(e){console.log("Plugin error: "+func);}});}
static update(dev_id,id,data){let func=dev_id+'_update_'+data.func;if(typeof window[func]==="function"){try{window[func](id,data);}catch(e){console.log("Plugin error: "+e);}}}};
class UiSelect{constructor(cont,data){cont.innerHTML=`<select data-type="${data.type}" class="w_select" style="color:${intToCol(data.color) ?? 'var(--prim)'}" id='${ID(data.id)}' value="${data.value ?? ''}" onchange="post_set('${data.id}',this.value)"></select>`;waitFrame().then(()=>UiSelect.render(data.id,data.text,data.value??''));Widget.disable(data.id,data.dsbl);}
static async render(id,text,value){let el=CMP(id);while(el.options.length>0)el.remove(0);if(text){let ops=text.toString().split(';');for(let i in ops){let option=document.createElement('option');option.value=i;option.text=ops[i].trim();option.selected=(i==value);el.add(option);}}}
static update(id,data){let el=CMP(id);if('value'in data)el.value=data.value;if('text'in data)UiSelect.render(id,data.text,el.value);if('color'in data)el.style.color=intToCol(data.color);}};
class UiColor{constructor(cont,data){cont.innerHTML=`
<div data-type="${data.type}" id="${ID(data.id)}" style="visibility:hidden">
<div id="picker#${data.id}"></div>
</div>
<button id="picker_btn#${data.id}" style="margin-left:-25px;color:${intToCol(data.value) ?? '#000'}" class="icon icon_btn_big" onclick="UiColor.open('${data.id}')"></button>
`;Widget.disable(data.id,data.dsbl);waitFrame().then(()=>{let el=EL('picker#'+data.id);if(!el)return;let p=Pickr.create({el:el,theme:'nano',default:intToCol(data.color)??'#000',defaultRepresentation:'HEXA',components:{preview:true,hue:true,interaction:{hex:false,input:true,save:true}}}).on('save',(color)=>{let col=color.toHEXA().toString();post_set(data.id,colToInt(col));EL('picker_btn#'+data.id).style.color=col;});UiColor.pickers[data.id]=p;});}
static update(id,data){let col=null;if('value'in data)col=intToCol(data.value);if('color'in data)col=intToCol(data.color);if(col){try{EL('picker_btn#'+id).style.color=col;UiColor.pickers[id].setColor(col);}catch(e){}}}
static open(id){let el=CMP(id);if(el.getAttribute("disabled"))return;el.getElementsByTagName('button')[0].click()}
static reset(){UiColor.pickers={};}
static pickers={};};
class UiLED{constructor(cont,data){cont.innerHTML=`
<style id="style#${data.id}"></style>
<div data-type="${data.type}" id="${ID(data.id)}" class="w_led ${Number(data.value ?? 0) ? 'w_led_on' : 'w_led_off'}"></div>`;UiLED.color(data.id,intToCol(data.color)??getDefColor());Widget.disable(data.id,data.dsbl);}
static update(id,data){let el=CMP(id);if('value'in data){el.classList.remove('w_led_on');el.classList.remove('w_led_off');if(Number(data.value))el.classList.add('w_led_on');else el.classList.add('w_led_off');}
if('color'in data)UiLED.color(id,intToCol(data.color));}
static color(id,color){EL('style#'+id).innerHTML=`
#${ID(id)}.w_led_on {
background: ${color};
box-shadow: ${color} 0 0 9px 1px, inset 2px 3px 0px 0px #fff3;
}`;}};
class UiFile{constructor(cont,data,contType,single){let params={type:"ui_json",cont:cont,path:data.value,contType:contType,single:single};hub.dev(focused).addFile(data.id,data.value,params);}
static async apply(json,data){let controls=null;try{controls=JSON.parse('['+json+']');}catch(e){console.log('JSON parse error in ui_json from '+data.path);}
await ui_render.render(data.cont,data.contType,controls,data.single);UiHook.update();}};
class UiHook{static reset(){UiHook.hooks={};}
static add(id,value){UiHook.hooks[id]={value:value};}
static update(){for(let id in UiHook.hooks)applyUpdate(id,UiHook.hooks[id]);}
static hooks;};
class UiGauge{constructor(cont,data){cont.innerHTML=`<canvas data-type="${data.type}" id="${ID(data.id)}"></canvas>`;waitFrame().then(()=>waitFrame()).then(()=>{let gauge=new Gauge(CMP(data.id),data);gauge.redraw();UiGauge.gauges[data.id]=gauge;});}
static update(id,data){let gauge=UiGauge.gauges[id];if(gauge)gauge.update(data);}
static resize(){for(let gag in UiGauge.gauges){UiGauge.gauges[gag].redraw();}}
static reset(){UiGauge.gauges={};}
static gauges={};};class Gauge{constructor(cv,data){this.perc=null;this.value=Number(data.value??0);this.min=Number(data.min??0);this.max=Number(data.max??100);this.dec=Number(data.dec??0);this.unit=data.unit??'';this.color=intToCol(data.color)??getDefColor();this.cv=cv;this.tout=null;this.redraw();}
stop(){if(this.tout)clearTimeout(this.tout);}
redraw(){let cv=this.cv;let rw=cv.parentNode.clientWidth;if(!rw)return;let rh=Math.floor(rw*0.47);cv.style.width=rw+'px';cv.style.height=rh+'px';cv.width=Math.floor(rw*ratio());cv.height=Math.floor(rh*ratio());let cx=cv.getContext("2d");let v=themes[cfg.theme];let perc=(this.value-this.min)*100/(this.max-this.min);if(perc<0)perc=0;if(perc>100)perc=100;if(this.perc==null)this.perc=perc;else{if(Math.abs(this.perc-perc)<=0.2)this.perc=perc;else this.perc+=(perc-this.perc)*0.2;if(this.perc!=perc)setTimeout(()=>this.redraw(),30);}
cx.clearRect(0,0,cv.width,cv.height);cx.lineWidth=cv.width/8;cx.strokeStyle=theme_cols[v][4];cx.beginPath();cx.arc(cv.width/2,cv.height*0.97,cv.width/2-cx.lineWidth,Math.PI*(1+this.perc/100),Math.PI*2);cx.stroke();cx.strokeStyle=this.color;cx.beginPath();cx.arc(cv.width/2,cv.height*0.97,cv.width/2-cx.lineWidth,Math.PI,Math.PI*(1+this.perc/100));cx.stroke();let font=cfg.font;cx.fillStyle=this.color;cx.font='10px '+font;cx.textAlign="center";let text=this.unit;let len=Math.max((this.value.toFixed(this.dec)+text).length,(this.min.toFixed(this.dec)+text).length,(this.max.toFixed(this.dec)+text).length);if(len==1)text+='  ';else if(len==2)text+=' ';let w=Math.max(cx.measureText(this.value.toFixed(this.dec)+text).width,cx.measureText(this.min.toFixed(this.dec)+text).width,cx.measureText(this.max.toFixed(this.dec)+text).width);if(this.value>this.max||this.value<this.min)cx.fillStyle=getErrColor();else cx.fillStyle=theme_cols[v][3];cx.font=cv.width*0.43*10/w+'px '+font;cx.fillText(this.value.toFixed(this.dec)+this.unit,cv.width/2,cv.height*0.93);cx.font='10px '+font;w=Math.max(cx.measureText(Math.round(this.min)).width,cx.measureText(Math.round(this.max)).width);cx.fillStyle=theme_cols[v][2];cx.font=cx.lineWidth*0.55*10/w+'px '+font;cx.fillText(this.min,cx.lineWidth,cv.height*0.92);cx.fillText(this.max,cv.width-cx.lineWidth,cv.height*0.92);}
update(data){let g=this.data;if('value'in data)this.value=Number(data.value);if('min'in data)this.min=Number(data.min);if('max'in data)this.max=Number(data.max);if('dec'in data)this.dec=Number(data.dec);if('unit'in data)this.unit=data.unit;if('color'in data)this.color=intToCol(data.color);this.redraw();}};
class UiGaugeR{constructor(cont,data){cont.innerHTML=`<canvas data-type="${data.type}" id="${ID(data.id)}"></canvas>`;waitFrame().then(()=>waitFrame()).then(()=>{let gauge=new GaugeR(CMP(data.id),data);gauge.redraw();UiGaugeR.gauges[data.id]=gauge;});}
static update(id,data){let gauge=UiGaugeR.gauges[id];if(gauge)gauge.update(data);}
static resize(){for(let gag in UiGaugeR.gauges){UiGaugeR.gauges[gag].redraw();}}
static reset(){UiGaugeR.gauges={};}
static gauges={};};class GaugeR{constructor(cv,data){this.perc=null;this.value=Number(data.value??0);this.min=Number(data.min??0);this.max=Number(data.max??100);this.dec=Number(data.dec??0);this.unit=data.unit??'';this.color=intToCol(data.color)??getDefColor();this.cv=cv;this.tout=null;this.redraw();}
stop(){if(this.tout)clearTimeout(this.tout);}
redraw(){let cv=this.cv;let rw=cv.parentNode.clientWidth;if(!rw)return;cv.style.width=rw+'px';cv.style.height=cv.style.width;cv.width=Math.floor(rw*ratio());cv.height=cv.width;let cx=cv.getContext("2d");let v=themes[cfg.theme];let perc=(this.value-this.min)*100/(this.max-this.min);if(perc<0)perc=0;if(perc>100)perc=100;if(this.perc==null)this.perc=perc;else{if(Math.abs(this.perc-perc)<=0.2)this.perc=perc;else this.perc+=(perc-this.perc)*0.2;if(this.perc!=perc)setTimeout(()=>this.redraw(),30);}
let joint=Math.PI*(0.5+2*(this.perc/100));cx.clearRect(0,0,cv.width,cv.height);cx.lineWidth=cv.width/8;cx.strokeStyle=theme_cols[v][4];cx.beginPath();cx.arc(cv.width/2,cv.height/2,cv.width/2-cx.lineWidth,joint,Math.PI*2.5);cx.stroke();cx.strokeStyle=this.color;cx.beginPath();cx.arc(cv.width/2,cv.height/2,cv.width/2-cx.lineWidth,Math.PI/2,joint);cx.stroke();let font=cfg.font;cx.fillStyle=this.color;cx.font='10px '+font;cx.textAlign="center";cx.textBaseline="middle";let text=this.unit;let len=Math.max((this.value.toFixed(this.dec)+text).length,(this.min.toFixed(this.dec)+text).length,(this.max.toFixed(this.dec)+text).length);if(len==1)text+='  ';else if(len==2)text+=' ';let w=Math.max(cx.measureText(this.value.toFixed(this.dec)+text).width,cx.measureText(this.min.toFixed(this.dec)+text).width,cx.measureText(this.max.toFixed(this.dec)+text).width);if(this.value>this.max||this.value<this.min)cx.fillStyle=getErrColor();else cx.fillStyle=theme_cols[v][3];cx.font=cv.width*0.5*10/w+'px '+font;cx.fillText(this.value.toFixed(this.dec)+this.unit,cv.width/2,cv.height*0.52);}
update(data){let g=this.data;if('value'in data)this.value=Number(data.value);if('min'in data)this.min=Number(data.min);if('max'in data)this.max=Number(data.max);if('dec'in data)this.dec=Number(data.dec);if('unit'in data)this.unit=data.unit;if('color'in data)this.color=intToCol(data.color);this.redraw();}};
class UiJoy{constructor(cont,data){cont.innerHTML=`<canvas data-type="${data.type}" id="${ID(data.id)}"></canvas>`;waitFrame().then(()=>{let id=data.id;let cb=function(d){post_set_prd(id,((d.x+255)<<16)|(d.y+255));if(!UiJoy.joys[id].suffix){EL('wsuffix#'+id).innerHTML='['+d.x+','+d.y+']';}}
let joy=new Joy(CMP(id),data,cb);joy.redraw(false);UiJoy.joys[id]=joy;});Widget.disable(data.id,data.dsbl);}
static update(id,data){}
static reset(){for(let joy in UiJoy.joys)UiJoy.joys[joy].stop();UiJoy.joys={};}
static resize(){for(let joy in UiJoy.joys){UiJoy.joys[joy].reset();UiJoy.joys[joy].redraw(false);}}
static joys={};};class Joy{keep=0;exp=0;color=0;center=0;posX=null;posY=null;pressed=0;constructor(cv,data,cb){this.color=intToCol(data.color)??getDefColor();this.keep=data.keep??0;this.exp=data.exp??0;this.cv=cv;this.cb=cb;if("ontouchstart"in document.documentElement){cv.addEventListener("touchstart",this._onTouchStart,{passive:false});document.addEventListener("touchmove",this._onTouchMove,{passive:false});document.addEventListener("touchend",this._onTouchEnd);}else{cv.addEventListener("mousedown",this._onMouseDown);document.addEventListener("mousemove",this._onMouseMove);document.addEventListener("mouseup",this._onMouseUp);}}
stop(){if("ontouchstart"in document.documentElement){this.cv.removeEventListener("touchstart",this._onTouchStart);document.removeEventListener("touchmove",this._onTouchMove);document.removeEventListener("touchend",this._onTouchEnd);}else{this.cv.removeEventListener("mousedown",this._onMouseDown);document.removeEventListener("mousemove",this._onMouseMove);document.removeEventListener("mouseup",this._onMouseUp);}}
reset(){this.posX=null;this.posY=null;}
redraw(send=true){let cv=this.cv;let size=cv.parentNode.clientWidth;if(!size)return;cv.style.width=size+'px';cv.style.height=size+'px';size*=ratio();cv.width=size;cv.height=size;cv.style.cursor='pointer';let r=size*0.23;let R=size*0.4;this.center=size/2;if(this.posX===null)this.posX=this.center;if(this.posY===null)this.posY=this.center;this.posX=constrain(this.posX,r,size-r);this.posY=constrain(this.posY,r,size-r);let x=Math.round((this.posX-this.center)/(size/2-r)*255);let y=-Math.round((this.posY-this.center)/(size/2-r)*255);let cx=cv.getContext("2d");cx.clearRect(0,0,size,size);cx.beginPath();cx.arc(this.center,this.center,R,0,2*Math.PI,false);let grd=cx.createRadialGradient(this.center,this.center,R*2/3,this.center,this.center,R);grd.addColorStop(0,'#00000005');grd.addColorStop(1,'#00000030');cx.fillStyle=grd;cx.fill();cx.beginPath();cx.arc(this.posX,this.posY,r,0,2*Math.PI,false);grd=cx.createRadialGradient(this.posX,this.posY,0,this.posX,this.posY,r);grd.addColorStop(0,adjustColor(this.color,0.7));grd.addColorStop(1,adjustColor(this.color,this.pressed?1.3:1));cx.fillStyle=grd;cx.fill();if(this.exp){x=((x*x+255)>>8)*(x>0?1:-1);y=((y*y+255)>>8)*(y>0?1:-1);}
if(send)this.cb({x:x,y:y});}
_onTouchStart=(event)=>{if(this.disabled())return;event.preventDefault();this.pressed=1;}
_onTouchMove=(event)=>{if(this.pressed){event.preventDefault();let target=null;for(let t of event.changedTouches){if(t.target===this.cv)target=t;}
if(!target)return;this.posX=target.pageX;this.posY=target.pageY;if(this.cv.offsetParent.tagName.toUpperCase()==="BODY"){this.posX-=this.cv.offsetLeft;this.posY-=this.cv.offsetTop;}else{this.posX-=this.cv.offsetParent.offsetLeft;this.posY-=this.cv.offsetParent.offsetTop;}
this.posX*=ratio();this.posY*=ratio();this.redraw();}}
_onTouchEnd=(event)=>{if(this.pressed){let target=null;for(let t of event.changedTouches){if(t.target===this.cv)target=t;}
if(!target)return;this.pressed=0;if(!this.keep){this.posX=this.center;this.posY=this.center;}
this.redraw();}}
_onMouseDown=(event)=>{if(this.disabled())return;this.pressed=1;document.body.style.userSelect='none';}
_onMouseMove=(event)=>{if(this.pressed){this.posX=event.pageX;this.posY=event.pageY;if(this.cv.offsetParent.tagName.toUpperCase()==="BODY"){this.posX-=this.cv.offsetLeft;this.posY-=this.cv.offsetTop;}else{this.posX-=this.cv.offsetParent.offsetLeft;this.posY-=this.cv.offsetParent.offsetTop;}
this.posX*=ratio();this.posY*=ratio();this.redraw();}}
_onMouseUp=(event)=>{if(this.pressed){this.pressed=0;if(!this.keep){this.posX=this.center;this.posY=this.center;}
this.redraw();document.body.style.userSelect='unset';}}
disabled(){return this.cv.getAttribute('disabled');}};
class UiDpad{constructor(cont,data){cont.innerHTML=`<canvas data-type="${data.type}" id="${ID(data.id)}"></canvas>`;waitFrame().then(()=>{let id=data.id;let cb=function(d){post_set_prd(id,((d.x+255)<<16)|(d.y+255));}
let pad=new Dpad(CMP(id),data,cb);pad.redraw(false);UiDpad.pads[id]=pad;});Widget.disable(data.id,data.dsbl);}
static update(id,data){}
static resize(){for(let pad in UiDpad.pads){UiDpad.pads[pad].redraw(false);}}
static reset(){for(let pad in UiDpad.pads)UiDpad.pads[pad].stop();UiDpad.pads={};}
static pads={};};class Dpad{color=0;posX=0;posY=0;pressed=0;constructor(cv,data,cb){this.color=intToCol(data.color)??getDefColor();this.cv=cv;this.cb=cb;if("ontouchstart"in document.documentElement){cv.addEventListener("touchstart",this._onTouchStart);document.addEventListener("touchend",this._onTouchEnd);}else{cv.addEventListener("mousedown",this._onMouseDown);document.addEventListener("mouseup",this._onMouseUp);}}
stop(){if("ontouchstart"in document.documentElement){this.cv.removeEventListener("touchstart",this._onTouchStart);document.removeEventListener("touchend",this._onTouchEnd);}else{this.cv.removeEventListener("mousedown",this._onMouseDown);document.removeEventListener("mouseup",this._onMouseUp);}}
redraw(send=true){let cv=this.cv;let size=cv.parentNode.clientWidth;if(!size)return;cv.style.width=size+'px';cv.style.height=size+'px';size*=ratio();let center=size/2;cv.width=size;cv.height=size;cv.style.cursor='pointer';let x=0;let y=0;if(this.pressed){x=Math.round((this.posX-center)/(size/2)*255);y=-Math.round((this.posY-center)/(size/2)*255);if(Math.abs(x)<50&&Math.abs(y)<50){x=0;y=0;}else{if(Math.abs(x)>Math.abs(y)){x=Math.sign(x);y=0;}else{x=0;y=Math.sign(y);}}}
let cx=cv.getContext("2d");cx.clearRect(0,0,size,size);cx.beginPath();cx.arc(center,center,size*0.44,0,2*Math.PI,false);cx.lineWidth=size*0.02;cx.strokeStyle=adjustColor(this.color,this.pressed?1.3:1);cx.stroke();cx.lineWidth=size*0.045;let rr=size*0.36;let cw=size*0.1;let ch=rr-cw;let sh=[[1,0],[-1,0],[0,1],[0,-1]];for(let i=0;i<4;i++){cx.beginPath();cx.strokeStyle=(x==sh[i][0]&&y==-sh[i][1])?adjustColor(this.color,1.3):this.color;cx.moveTo(center+ch*sh[i][0]-cw*sh[i][1],center+ch*sh[i][1]-cw*sh[i][0]);cx.lineTo(center+rr*sh[i][0],center+rr*sh[i][1]);cx.lineTo(center+ch*sh[i][0]+cw*sh[i][1],center+ch*sh[i][1]+cw*sh[i][0]);cx.stroke();}
if(send)this.cb({x:x,y:y});}
_onTouchStart=(event)=>{if(this.disabled())return;event.preventDefault();this.pressed=1;this.posX=(event.targetTouches[0].pageX-this.cv.offsetLeft)*ratio();this.posY=(event.targetTouches[0].pageY-this.cv.offsetTop)*ratio();this.redraw();}
_onTouchEnd=(event)=>{if(this.pressed){this.pressed=0;this.redraw();}}
_onMouseDown=(event)=>{if(this.disabled())return;this.pressed=1;this.posX=(event.pageX-this.cv.offsetLeft)*ratio();this.posY=(event.pageY-this.cv.offsetTop)*ratio();this.redraw();}
_onMouseUp=(event)=>{if(this.pressed){this.pressed=0;this.redraw();}}
disabled(){return this.cv.getAttribute('disabled');}};
class UiFlags{constructor(cont,data){cont.innerHTML=`
<style id="style#${data.id}"></style>
<div data-type="${data.type}" id="${ID(data.id)}" class="w_flags_cont w_flags_cont_tab" data-text="${data.text ?? ''}" data-value="${data.value ?? 0}"></div>`;UiFlags.render(data.id);UiFlags.color(data.id,intToCol(data.color)??getDefColor());Widget.disable(data.id,data.dsbl);waitFrame().then(()=>UiFlags.resize(data.id));}
static update(id,data){let el=CMP(id);if('value'in data)el.setAttribute("data-value",data.value);if('text'in data)el.setAttribute("data-text",data.text);if('color'in data)UiFlags.color(id,data.color);UiFlags.render(id);}
static render(id){let el=CMP(id);let val=Number(el.getAttribute("data-value"));let text=el.getAttribute("data-text");el.innerHTML="";let labels=text.split(';');for(let i=0;i<labels.length;i++){el.innerHTML+=`
<label id="flags_${id}" class="w_flags w_flags_txt">
<input name="${id}" type="checkbox" onclick="UiFlags.click('${id}',this)" ${(val & 1) ? 'checked' : ''}>
<span class="w_flags_s w_flags_span">${labels[i]}</span>
</label>`;val>>=1;}}
static color(id,color){if(color){EL('style#'+id).innerHTML=`
#flags_${id} input:checked+.w_flags_s{background:${color}}`;}}
static click(id,el){if(CMP(id).getAttribute("disabled"))return;let flags=document.getElementsByName(id);let encoded=0;flags.forEach((w,i)=>{if(w.checked)encoded|=(1<<flags.length);encoded>>=1;});post_set(id,encoded);}
static resize(id){let txt=CMP(id).querySelectorAll(".w_flags_txt");let span=CMP(id).querySelectorAll(".w_flags_span");txt.forEach((ch,i)=>{let len=span[i].innerHTML.length+2;txt[i].style.width=(len+0.5)+'ch';span[i].style.width=len+'ch';});}};
class UiTabs{constructor(cont,data){let tabs='';if(data.text){let labels=data.text.split(';');for(let i in labels){tabs+=`<li onclick="UiTabs.click('${data.id}',${i})">${labels[i].trim()}</li>`;}}
cont.innerHTML=`
<style id="style#${data.id}"></style>
<div data-type="${data.type}" id="${ID(data.id)}" class="w_tabs"><ul onwheel="UiTabs.wheel(event,this)">${tabs}</ul></div>`;UiTabs.color(data.id,intToCol(data.color)??getDefColor());waitFrame().then(()=>UiTabs.change(data.id,data.value??0));Widget.disable(data.id,data.dsbl);}
static click(id,num){if(CMP(id).getAttribute("disabled"))return;post_set(id,num);UiTabs.change(id,num,false);}
static change(id,num,move=true){let el=CMP(id);let list=el.children[0].children;for(let i=0;i<list.length;i++){if(i==num)list[i].classList.add('w_tab_act');else list[i].classList.remove('w_tab_act');}
if(move)el.children[0].scrollLeft=el.children[0].scrollWidth*num/list.length;}
static update(id,data){if('value'in data)UiTabs.change(id,Number(data.value));if('color'in data)UiTabs.color(id,data.color);}
static color(id,color){if(color){EL('style#'+id).innerHTML=`
#${ID(id)}.w_tabs>ul>li.w_tab_act {background: ${color} !important;}`;}}
static wheel(e,el){e.preventDefault();el.scrollLeft+=e.deltaY;}};
class UiCanvas{constructor(cont,data){cont.innerHTML=`<div class="w_canvas"><canvas data-type="${data.type}" id="${ID(data.id)}" onclick="UiCanvas.click('${data.id}',event)"></canvas></div>`;waitFrame().then(()=>{let cv=new Canvas(data.id,CMP(data.id),data.width,data.height,data.active);cv.update(data.data);cv.show();UiCanvas.canvases[data.id]=cv;});Widget.disable(data.id,data.dsbl);}
static update(id,data){let cv=UiCanvas.canvases[id];if(!cv)return;if('data'in data){cv.update(data.data);cv.show(data.data);}}
static reset(){UiCanvas.canvases={};}
static resize(){for(let cv in UiCanvas.canvases){UiCanvas.canvases[cv].resize();}}
static click(id,e){let cv=UiCanvas.canvases[id];if(!cv||!cv.active)return;let rect=CMP(id).getBoundingClientRect();let x=Math.round((e.clientX-rect.left)/cv.scale*ratio());if(x<0)x=0;let y=Math.round((e.clientY-rect.top)/cv.scale*ratio());if(y<0)y=0;post_set(id,(x<<16)|y);EL('wsuffix#'+id).innerHTML='['+x+','+y+']';}
static canvases={};};class Canvas{constructor(id,cv,w,h,active){this.data=[];this.id=id;this.cv=cv;this.width=w;this.height=h;this.scale=1;this.active=active;if(active)cv.style.cursor='pointer';this.resize();}
clear(){this.data=[];}
resize(){let rw=this.cv.parentNode.clientWidth;let scale=rw/this.width;this.scale=scale*ratio();let rh=Math.floor(this.height*scale);this.cv.style.width=rw+'px';this.cv.style.height=rh+'px';this.cv.width=Math.floor(rw*ratio());this.cv.height=Math.floor(rh*ratio());this.show(this.data);}
update(data){this.data=this.data.concat(data);}
show(data=null){if(!data)data=this.data;let cv=this.cv;let cx=cv.getContext("2d");let ev_str='';const cmd_list=['fillStyle','strokeStyle','shadowColor','shadowBlur','shadowOffsetX','shadowOffsetY','lineWidth','miterLimit','font','textAlign','textBaseline','lineCap','lineJoin','globalCompositeOperation','globalAlpha','scale','rotate','rect','fillRect','strokeRect','clearRect','moveTo','lineTo','quadraticCurveTo','bezierCurveTo','translate','arcTo','arc','fillText','strokeText','drawImage','roundRect','fill','stroke','beginPath','closePath','clip','save','restore'];const const_list=['butt','round','square','square','bevel','miter','start','end','center','left','right','alphabetic','top','hanging','middle','ideographic','bottom','source-over','source-atop','source-in','source-out','destination-over','destination-atop','destination-in','destination-out','lighter','copy','xor','top','bottom','middle','alphabetic'];let cv_map=(v,h)=>{v*=this.scale;return v>=0?v:(h?cv.height:cv.width)-v;}
let scale=()=>{return this.scale;}
for(let d of data){let div=d.indexOf(':');let cmd=parseInt(d,10);if(!isNaN(cmd)&&cmd<=37){if(div==1||div==2){let val=d.slice(div+1);let vals=val.split(',').map(v=>(v>0)?v=Number(v):v);if(cmd<=2)ev_str+=('cx.'+cmd_list[cmd]+'=\''+intToColA(val)+'\';');else if(cmd<=7)ev_str+=('cx.'+cmd_list[cmd]+'='+(val*scale())+';');else if(cmd<=13)ev_str+=('cx.'+cmd_list[cmd]+'=\''+const_list[val]+'\';');else if(cmd<=14)ev_str+=('cx.'+cmd_list[cmd]+'='+val+';');else if(cmd<=16)ev_str+=('cx.'+cmd_list[cmd]+'('+val+');');else if(cmd<=26){let str='cx.'+cmd_list[cmd]+'(';for(let i in vals){if(i>0)str+=',';str+=`cv_map(${vals[i]},${(i % 2)})`;}
ev_str+=(str+');');}else if(cmd==27){ev_str+=(`cx.${cmd_list[cmd]}(cv_map(${vals[0]},0),cv_map(${vals[1]},1),cv_map(${vals[2]},0),${vals[3]},${vals[4]},${vals[5]});`);}else if(cmd<=29){ev_str+=(`cx.${cmd_list[cmd]}(${vals[0]},cv_map(${vals[1]},0),cv_map(${vals[2]},1),${vals[3]});`);}else if(cmd==30){let img=new Image();for(let i in vals){if(i>0)vals[i]=cv_map(vals[i],!(i%2));}
if(vals[0].startsWith('http://')||vals[0].startsWith('https://')){img.src=vals[0];}else{hub.dev(focused).addFile(this.id,vals[0],{type:"cv_img",img:img});}
img.onload=function(){let ev='cx.drawImage(img';for(let i in vals){if(i>0)ev+=','+vals[i];}
if(vals.length-1==3){ev+=','+vals[3]*img.height/img.width;}
ev+=')';eval(ev);}}else if(cmd==31){let str='cx.'+cmd_list[cmd]+'(';for(let i=0;i<4;i++){if(i>0)str+=',';str+=`cv_map(${vals[i]},${(i % 2)})`;}
if(vals.length==5)str+=`,${vals[4] * scale()}`;else{str+=',[';for(let i=4;i<vals.length;i++){if(i>4)str+=',';str+=`cv_map(${vals[i]},${(i % 2)})`;}
str+=']';}
ev_str+=(str+');');}}else{if(cmd>=32)ev_str+=('cx.'+cmd_list[cmd]+'();');}}else{ev_str+=d+';';}}
eval(ev_str);}};
class UiStream{constructor(cont,data){cont.innerHTML=`<div><img style="width:100%" src="http://${ip}:${port}/"></div>`;}
static update(id,data){}};
const set_prd=15;let set_prd_buf={};function post(cmd,name='',value=''){if(focused)hub.post(focused,cmd,name,value);}
function post_click(name,dir){UiButton.pressID=(dir==1)?name:null;post('set',name,dir);}
function post_set(name,value=''){post('set',name,value);setPlabel(name,'•');}
function post_set_prd(name,value){if(!(name in set_prd_buf))set_prd_buf[name]={value:null,tout:null};if(!set_prd_buf[name].tout){post_set(name,value);set_prd_buf[name].tout=setTimeout(()=>{if(set_prd_buf[name]&&set_prd_buf[name].value!=null){post_set(name,set_prd_buf[name].value);}
delete set_prd_buf[name];},set_prd);}else{set_prd_buf[name].value=value;}}
function reboot_h(){post('reboot');}
function release_all(){if(UiButton.pressID)post('set',UiButton.pressID,0);UiButton.pressID=null;}
let ui_render=new UiRender();function showControls(id,controls){function changeID(node){for(var i=0;i<node.childNodes.length;i++){let child=node.childNodes[i];changeID(child);if(child.id)child.id+='__old';}}
if(!controls)return;let dev=hub.dev(id);let cont=document.createElement("div");ui_render.root=cont;cont.classList.add('main_col');cont.style.visibility='hidden';cont.id='controls#'+id;cont.style.maxWidth=dev.info.main_width+'px';if(dev.info.ui_mode>=2){cont.style.display='grid';cont.style.gridTemplateColumns=`repeat(auto-fit, minmax(${dev.info.ui_block_width}px, 1fr))`;}else{cont.style.display='block';}
let excont=EL('controls#'+id);if(excont){cont.id+='_new';changeID(excont);}
EL('controls').appendChild(cont);set_prd_buf={};UiHook.reset();UiColor.reset();UiGauge.reset();UiGaugeR.reset();UiJoy.reset();UiDpad.reset();UiCanvas.reset();ui_render.reset();Menu.clear();dev.resetFiles();ui_render.render(cont,'col',controls,(dev.info.ui_mode==1||dev.info.ui_mode==3));UiFunc.render(cont);if(ui_render.dup_names.length)showPopupError('Duplicated names: '+ui_render.dup_names);hub.dev(focused).checkFiles();UiHook.update();waitFrame().then(()=>{if(excont){excont.remove();cont.id='controls#'+id;}
cont.style.visibility='visible';});}
function render_main(){document.body.innerHTML=`
<noscript>Browser is not supported</noscript>
<div id="notice" class="notice"></div>
<div class="head" id="head_cont"></div>
<div class="test" id="test_cont"></div>
<div class="projects" id="projects_cont"></div>
<div class="main" id="main_cont"></div>
<div class="cli" id="cli_cont"></div>
<div class="footer" id="footer_cont"></div>
<div id="qrcode" style="display: none"></div>
`;head_cont.innerHTML=`
<div class="title" id="title_cont">
<div class="title_inn">
<div id="title_row" class="title_row" onclick="back_h()">
<span class="icon icon_head back_btn" id="back"></span>
<span><span id="title">${app_title}</span><sup id="conn"></sup></span>
<div id="conn_icons">
<span id='bt_ok' class="icon icon_ui icon_ok"></span>
<span id='mqtt_ok' class="icon icon_ui icon_ok"></span>
<span id='serial_ok' class="icon icon_ui icon_ok"></span>
</div>
</div>
<div class="head_btns">
<span class="icon icon_head" id='icon_refresh' onclick="refresh_h()"></span>
<span class="icon icon_head" id='icon_cfg' style="display:none" onclick="config_h()"></span>
<span class="icon icon_head" id='icon_menu' style="display:none" onclick="menu_h()"></span>
</div>
</div>
</div>
`;cli_cont.innerHTML=`
<div class="cli_block">
<div class="cli_area" id="cli"></div>
<div class="cli_row">
<span class="icon cli_icon"></span>
<input type="text" class="ui_inp cli_inp" id="cli_input" onkeydown="checkCLI(event)">
<button class="icon icon_btn cli_icon cli_enter" onclick="sendCLI()"></button>
</div>
</div>
`;main_cont.innerHTML=`
<div id="menu_overlay" onclick="menu_show(0)"></div>
<div id="menu" class="main_col menu">
<div class="menu_inn">
<div id="menu_user"></div>
<div id="menu_system"></div>
</div>
</div>
<div class="main_inn">
<div id="plugins"></div>
<div id="app_plugins"></div>
<div id="devices" class="main_col"></div>
<div id="controls"></div>
<div id="info" class="main_col">
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>Settings</label>
</div>
<div class="ui_row">
<label>Console</label>
<label class="switch"><input type="checkbox" id="info_cli_sw" onchange="showCLI(this.checked);save_devices()">
<span class="slider"></span></label>
</div>
<div class="ui_row">
<label>UI mode</label>
<div class="ui_inp_row">
<select class="ui_inp ui_sel" id="ui_mode" onchange="ui_mode_h(this)">
<option value="0">Default</option>
<option value="1">Single row</option>
<option value="2">Responsive</option>
<option value="3">Grid</option>
</select>
</div>          
</div>
<div class="ui_row" id="ui_block_width_cont">
<label class="ui_label">Block width</label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" id="ui_block_width" onchange="ui_block_width_h(this)">
</div>
</div>
<div class="ui_row">
<label class="ui_label">Main width</label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" id="main_width" onchange="ui_width_h(this)">
</div>
</div>
<div class="ui_row">
<label class="ui_label">Plugin CSS</label>
<div class="ui_inp_row">
<textarea class="w_area" id="plugin_css" onchange="ui_plugin_css_h(this)"></textarea>
</div>
</div>
<div class="ui_row">
<label class="ui_label">Plugin JS</label>
<div class="ui_inp_row">
<textarea class="w_area" id="plugin_js" onchange="ui_plugin_js_h(this)"></textarea>
</div>
</div>
<div style="height:5px"></div>
<div class="ui_btn_row">
<button id="reboot_btn" class="ui_btn ui_btn_mini" onclick="reboot_h()"><span class="icon icon_inline"></span>Reboot</button>
<button id="devlink_btn" class="ui_btn ui_btn_mini" onclick="devlink_h()"><span class="icon icon_inline"></span>Link</button>
</div>
</div>
<div class="ui_col" id="info_topics">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>Topics</label>
</div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>Version</label>
</div>
<div id="info_version"></div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>Network</label>
</div>
<div id="info_net"></div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>Memory</label>
</div>
<div id="info_memory"></div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>System</label>
</div>
<div id="info_system"></div>
</div>
</div>
<div id="fsbr_edit" class="main_col">
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>Editor</label>
</div>
<div class="ui_row">
<label id="edit_path"></label>
</div>
<div class="ui_row">
<label>Wrap text</label>
<label class="switch"><input type="checkbox" id="editor_wrap" onchange="this.checked?editor_area.classList.remove('w_area_wrap'):editor_area.classList.add('w_area_wrap')"><span class="slider"></span></label>
</div>
<div class="ui_row">
<textarea rows=20 id="editor_area" class="ui_inp w_area w_area_wrap"></textarea>
</div>
<div class="ui_row">
<button id="editor_save" onclick="editor_save()" class="ui_btn ui_btn_mini">Save & Upload</button>
<button onclick="editor_cancel()" class="ui_btn ui_btn_mini">Cancel</button>
</div>
</div>
</div>
<div id="files" class="main_col">
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>FS browser</label>
</div>
<div id="fs_browser">
<div id="fsbr_inner"></div>
<div class="ui_row">
<div>
<button id="fs_format" onclick="format_h()" class="ui_btn ui_btn_mini">Format</button>
</div>
</div>
</div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>Upload to</label>
</div>
<div id="fs_upload">
<div class="upl_row">
<input class="ui_inp ui_inp_wbtn" type="text" id="file_upload_path" value="/">
<input type="file" id="file_upload" style="display:none" onchange="uploadFile(this.files[0], file_upload_path.value)">
<button id="file_upload_btn" onclick="file_upload.click()" class="ui_btn upl_btn">Upload</button>
</div>
</div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>Create file</label>
</div>
<div id="fs_create">
<div class="upl_row">
<input class="ui_inp ui_inp_wbtn" type="text" id="file_create_path" value="/">
<button onclick="create_h()" class="ui_btn upl_btn">Create</button>
</div>
</div>
</div>
</div>
<div id="ota" class="main_col">
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>OTA FILE</label>
</div>
<div id="fs_otaf">
<div class="ui_row">
<div>
<input type="file" id="ota_upload" style="display:none" onchange="uploadOta(this.files[0], 'flash')">
<button onclick="ota_upload.click()" class="ui_btn ui_btn_mini drop_area" ondrop="uploadOta(event.dataTransfer.files[0], 'flash')">Flash</button>
<input type="file" id="ota_upload_fs" style="display:none" onchange="uploadOta(this.files[0], 'fs')">
<button onclick="ota_upload_fs.click()" class="ui_btn ui_btn_mini drop_area" ondrop="uploadOta(event.dataTransfer.files[0], 'fs')">Filesystem</button>
</div>
<label style="font-size:18px" id="ota_label"></label>
</div>
</div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>OTA URL</label>
</div>
<div id="fs_otaurl">
<div class="upl_row">
<input class="ui_inp ui_inp_wbtn" type="text" id="ota_url_f">
<button id="ota_url_btn" onclick="otaUrl(ota_url_f.value,'flash')" class="ui_btn upl_btn">Flash</button>
</div>
<div class="upl_row">
<input class="ui_inp ui_inp_wbtn" type="text" id="ota_url_fs">
<button id="ota_url_btn" onclick="otaUrl(ota_url_fs.value,'fs')" class="ui_btn upl_btn">FS</button>
</div>
</div>
</div>
</div>
<div id="config" class="cfg_inner">
<div class="ui_col">
<div class="ui_row ui_head ui_tab" onclick="use_local.click()">
<label class="ui_label ui_tab" id="local_label"><span class="icon icon_ui"></span>Local</label>
<input type="checkbox" id="use_local" onchange="update_cfg(this)" style="display:none">
</div>
<div id="local_block" style="display:none">
<div class="ui_row" id="http_only_http" style="display:none">
<span style="color:#c60000">Works only on <strong class="span_btn" onclick="window.location.href = window.location.href.replace('https', 'http')">HTTP</strong>!</span>
</div>
<div id="http_settings">
<div class="ui_row">
<label class="ui_label">Local IP</label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" id="local_ip" onchange="update_cfg(this)">
<div class="btn_inp_block">
<button class="icon icon_btn" onclick="update_ip_h();update_cfg(EL('local_ip'))"></button>
</div>
</div>
</div>
<div class="ui_row">
<label>Netmask</label>
<div class="ui_inp_row">
<select class="ui_inp ui_sel" id="netmask" onchange="update_cfg(this)"></select>
</div>
</div>
<div class="ui_row">
<label>HTTP port</label>
<div class="ui_inp_row"><input class="ui_inp" type="text" id="http_port" onchange="update_cfg(this)"></div>
</div>
<div class="ui_row">
<label class="ui_label">Add by IP</label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" value="192.168.1.1" id="local_add_ip">
<div class="btn_inp_block">
<button class="icon icon_btn" onclick="manual_ip_h(local_add_ip.value)"></button>
</div>
</div>
</div>
<!--APP-->
<span class="notice_block">Disable: <u>${browser()}://flags/#block-insecure-private-network-requests</u></span>
<!--/APP-->
</div>
</div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label class="ui_label"><span class="icon icon_ui"></span>Settings</label>
</div>
<div class="ui_row">
<label class="ui_label">Search</label>
<button class="icon icon_btn_big" onclick="search();back_h();" title="Find new devices"></button>
</div>
<div class="ui_row">
<label class="ui_label">Prefix</label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" id="prefix" onchange="update_cfg(this)">
</div>
</div>
<div class="ui_row">
<label class="ui_label">Client ID</label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" id="client_id" onchange="update_cfg(this)" oninput="if(this.value.length>8)this.value=this.value.slice(0,-1)">
</div>
</div>
<div class="ui_row">
<label class="ui_label">Theme</label>
<div class="ui_inp_row">
<select class="ui_inp ui_sel" id='theme' onchange="update_cfg(this)"></select>
</div>
</div>
<div class="ui_row">
<label class="ui_label">Main Color</label>
<div class="ui_inp_row">
<select class="ui_inp ui_sel" id='maincolor' onchange="update_cfg(this)"></select>
</div>
</div>
<div class="ui_row">
<label class="ui_label">Font</label>
<div class="ui_inp_row">
<select class="ui_inp ui_sel" id='font' onchange="update_cfg(this)"></select>
</div>
</div>
<div class="ui_row">
<label class="ui_label">Lang</label>
<div class="ui_inp_row">
<select class="ui_inp ui_sel" id='lang' onchange="update_cfg(this)"></select>
</div>
</div>
<div class="ui_row">
<label class="ui_label">UI Width</label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" id="ui_width" onchange="update_cfg(this);update_theme()">
</div>
</div>
<div class="ui_row">
<label class="ui_label">Plugin CSS</label>
<div class="ui_inp_row">
<textarea class="w_area" id="app_plugin_css" onchange="update_cfg(this);update_theme()"></textarea>
</div>
</div>
<div class="ui_row">
<label class="ui_label">Plugin JS</label>
<div class="ui_inp_row">
<textarea class="w_area" id="app_plugin_js" onchange="update_cfg(this);update_theme()"></textarea>
</div>
</div>
<div class="ui_row">
<label>Check updates</label>
<label class="switch"><input type="checkbox" id="check_upd" onchange="update_cfg(this)"><span class="slider"></span></label>
</div>
<div class="ui_row">
<label class="ui_label">Settings</label>
<div class="ui_btn_row">
<button class="ui_btn ui_btn_mini" onclick="cfg_export()">Export</button>
<button class="ui_btn ui_btn_mini" onclick="cfg_import()">Import</button>
</div>
</div>
</div>
<div class="ui_col">
<div class="ui_row ui_head ui_tab" onclick="use_pin.click()">
<label id="pin_label" class="ui_label ui_tab"><span class="icon icon_ui"></span>PIN</label>
<input type="checkbox" id="use_pin" onchange="update_cfg(this)" style="display:none">
</div>
<div id="pin_block" style="display:none">
<div class="ui_row">
<label class="ui_label">PIN</label>
<div class="ui_inp_row"><input class="ui_inp" type="password" pattern="[0-9]*" inputmode="numeric"
id="pin" onchange="this.value=this.value.hashCode();update_cfg(this)" oninput="check_type(this)">
</div>
</div>
</div>
</div>
<div class="ui_col" id="app_block">
<div class="ui_row ui_head">
<label class="ui_label"><span class="icon icon_ui"></span>App</label>
<div class="ui_btn_row">
<button class="ui_btn ui_btn_mini" onclick="openURL('https://play.google.com/store/apps/details?id=ru.alexgyver.GyverHub')">Android</button>
<button class="ui_btn ui_btn_mini" onclick="openURL('https://github.com/GyverLibs/GyverHub/raw/main/app/GyverHub.apk')">.apk</button>
</div>
</div>
</div>
<div class="ui_col">
<div class="cfg_info" id="hub_stat"></div>
<div class="cfg_info">
Contribution:
<a href="https://github.com/Simonwep/pickr" target="_blank">Pickr</a>
<a href="https://github.com/mqttjs/MQTT.js" target="_blank">MQTT.js</a>
<a href="https://github.com/ghornich/sort-paths" target="_blank">sort-paths</a>
<a href="https://fontawesome.com/v5/search?o=r&m=free&s=solid" target="_blank">Fontawesome</a>
<a href="https://github.com/loginov-rocks/Web-Bluetooth-Terminal" target="_blank">Bluetooth Terminal</a>
<a href="https://github.com/davidshimjs/qrcodejs" target="_blank">QRCode.js</a>
</div>
</div>
</div>
<div id="password" class="main_col">
<div class="pass_inp_inner">
<input class="ui_inp pass_inp" type="number" pattern="[0-9]*" inputmode="numeric" id="pass_inp" oninput="pass_type('')">
</div>
<div class="ui_row pin_inner">
<button class="ui_btn pin_btn" onclick="pass_type(1)">1</button>
<button class="ui_btn pin_btn" onclick="pass_type(2)">2</button>
<button class="ui_btn pin_btn" onclick="pass_type(3)">3</button>
</div>
<div class="ui_row pin_inner">
<button class="ui_btn pin_btn" onclick="pass_type(4)">4</button>
<button class="ui_btn pin_btn" onclick="pass_type(5)">5</button>
<button class="ui_btn pin_btn" onclick="pass_type(6)">6</button>
</div>
<div class="ui_row pin_inner">
<button class="ui_btn pin_btn" onclick="pass_type(7)">7</button>
<button class="ui_btn pin_btn" onclick="pass_type(8)">8</button>
<button class="ui_btn pin_btn" onclick="pass_type(9)">9</button>
</div>
<div class="ui_row pin_inner">
<button class="ui_btn pin_btn pin_no_btn"></button>
<button class="ui_btn pin_btn" onclick="pass_type(0)">0</button>
<button class="ui_btn pin_btn pin_red_btn" onclick="pass_inp.value=pass_inp.value.slice(0, -1)">&lt;</button>
</div>
</div>
</div>
<div id="bottom_space"></div>
`;}
function render_selects(){for(let color in colors){EL('maincolor').innerHTML+=`
<option value="${color}">${color}</option>`;}
for(let lang in langs){EL('lang').innerHTML+=`
<option value="${lang}">${lang}</option>`;}
for(let font of fonts){EL('font').innerHTML+=`
<option value="${font}">${font}</option>`;}
for(let theme in themes){EL('theme').innerHTML+=`
<option value="${theme}">${theme}</option>`;}
let masks=getMaskList();for(let mask in masks){EL('netmask').innerHTML+=`<option value="${mask}">${masks[mask]}</option>`;}}
function render_info(){const info_labels_topics={info_id:'ID',info_set:'Set',info_read:'Read',info_get:'Get',info_status:'Status',};for(let id in info_labels_topics){EL('info_topics').innerHTML+=`
<div class="ui_row info">
<label>${info_labels_topics[id]}</label>
<label id="${id}" class="info_label info_label_small">-</label>
</div>`;}}
function add_device(dev){let icon=dev.icon;if(icon.length&&isESP())icon='';EL('devices').innerHTML+=`
<div class="device ${dev.conn == Conn.NONE ? 'offline' : ''}" id="device#${dev.id}" onclick="device_h('${dev.id}')" title="${dev.id} [${dev.prefix}]">
<div class="device_inner">
<div id="d_head#${dev.id}" style="display:contents">
<div class="d_icon ${icon.length ? '' : 'd_icon_empty'}"><span class="icon icon_min ${icon.length ? '' : 'd_icon_none'}" id="icon#${dev.id}">${getIcon(icon)}</span></div>
<div class="d_title">
<span><span class="d_name" id="name#${dev.id}">${dev.name}</span><sup class="conn_dev" id="Serial#${dev.id}">S</sup><sup class="conn_dev" id="BT#${dev.id}">B</sup><sup class="conn_dev" id="HTTP#${dev.id}">L</sup><sup class="conn_dev" id="MQTT#${dev.id}">M</sup></span>
</div>
</div>
<div id="d_cfg#${dev.id}" class="d_btn_cont">
<div class="icon d_btn_red" onclick="delete_h('${dev.id}');event.stopPropagation()"></div>
<div class="icon d_btn_green" onclick="dev_up_h('${dev.id}');event.stopPropagation()"></div>
<div class="icon d_btn_green" onclick="dev_down_h('${dev.id}');event.stopPropagation()"></div>
</div>
<span class="icon d_btn_cfg" onclick="dev_cfg_h('${dev.id}');event.stopPropagation()"></span>
</div>
</div>`;let device=hub.dev(dev.id);EL('d_head#'+dev.id).style.display=device.cfg_flag?'none':'contents';EL('d_cfg#'+dev.id).style.display=device.cfg_flag?'flex':'none';}
function render_devices(){EL('devices').innerHTML='';for(let dev of hub.devices){add_device(dev.info);for(let i in dev.conn_arr){if(dev.conn_arr[i])display(`${Conn.names[i]}#${dev.info.id}`,'inline-block');}}}
function dev_cfg_h(id){let dev=hub.dev(id);dev.cfg_flag=!dev.cfg_flag;EL('d_head#'+id).style.display=dev.cfg_flag?'none':'contents';EL('d_cfg#'+id).style.display=dev.cfg_flag?'flex':'none';}
let popupT1=null,popupT2=null;function showPopup(text,color='#37a93c'){if(popupT1)clearTimeout(popupT1);if(popupT2)clearTimeout(popupT2);EL('notice').innerHTML=text;EL('notice').style.background=color;display('notice','block');EL('notice').style.animation="fade-in 0.5s forwards";popupT1=setTimeout(()=>{popupT1=null;display('notice','none');},3500);popupT2=setTimeout(()=>{popupT2=null;EL('notice').style.animation="fade-out 0.5s forwards"},3000);}
function showPopupError(text){showPopup(text,'#a93737');}
function errorBar(v){EL('head_cont').style.background=v?'var(--err)':'var(--prim)';}
function spinArrows(val){if(val)EL('icon_refresh').classList.add('spinning');else EL('icon_refresh').classList.remove('spinning');}
function waiter(size=50,col='var(--prim)',block=true){return`<div class="waiter ${block ? 'waiter_b' : ''}"><span style="font-size:${size}px;color:${col}" class="icon spinning"></span></div>`;}
function setPlabel(name,text){let lb=EL('plabel#'+name);if(lb)lb.innerHTML=text;}
function mq_change(opened){display('mq_start',opened?'none':'inline-block');display('mq_stop',opened?'inline-block':'none');}
function bt_show_ok(state){display('bt_ok',state?'inline-block':'none');}
function bt_change(opened){display('bt_open',opened?'none':'inline-block');display('bt_close',opened?'inline-block':'none');}
function serial_show_ok(state){display('serial_ok',state?'inline-block':'none');}
function serial_change(opened){display('serial_open',opened?'none':'inline-block');display('serial_close',opened?'inline-block':'none');}
async function serial_toggle(state){serial_show_ok(false);serial_change(false);if(!state)hub.serial.close();serial_check_ports();}
async function serial_check_ports(){if(!hasSerial())return;const ports=await hub.serial.getPorts();display('serial_open',ports.length?'inline-block':'none');}
function showInfo(info){function addInfo(el,label,value,title=''){EL(el).innerHTML+=`
<div class="ui_row info">
<label>${label}</label>
<label title="${title}" class="info_label">${value}</label>
</div>`;}
EL('info_version').innerHTML='';EL('info_net').innerHTML='';EL('info_memory').innerHTML='';EL('info_system').innerHTML='';for(let i in info.version)addInfo('info_version',i,info.version[i]);for(let i in info.net)addInfo('info_net',i,info.net[i]);for(let i in info.memory){if(typeof(info.memory[i])=='object'){let used=info.memory[i][0];let total=info.memory[i][1];let mem=(used/1000).toFixed(1)+' kB';if(total)mem+=' ['+(used/total*100).toFixed(0)+'%]';addInfo('info_memory',i,mem,`Total ${(total / 1000).toFixed(1)} kB`);}else addInfo('info_memory',i,info.memory[i]);}
for(let i in info.system){if(i=='Uptime'){let sec=info.system[i];let upt=Math.floor(sec/86400)+':'+new Date(sec*1000).toISOString().slice(11,19);let d=new Date();let utc=d.getTime()-(d.getTimezoneOffset()*60000);addInfo('info_system',i,upt);addInfo('info_system','Started',new Date(utc-sec*1000).toISOString().split('.')[0].replace('T',' '));continue;}
addInfo('info_system',i,info.system[i]);}}
const lang={English:{errors:["not an error","open file error","not enough space","checksum error","size error","start error","write error","end error","aborted","timeout","busy","memory error","wrong client","forbidden","module disabled","FS busy","cancelled"],done:"Done",error:"Error",upload:"Upload",fetch:"Fetch",connecting:"Connecting",connected:"Connected",disconnected:"Disconnected",},Russian:{errors:["не ошибка","невозможно открыть файл","недостаточно места","ошибка контрольной суммы","ошибка размера","ошибка старта","ошибка записи","ошибка завершения","прервано","тайм-аут","занят","ошибка памяти","не тот клиент","запрещено","модуль отключен","система занята","отменено"],done:"Завершено",error:"Ошибка",upload:"Загрузка",fetch:"Скачивание",connecting:"Подключение",connected:"Подключено",disconnected:"Отключено",}};
function update_cfg(el){if(el.type=='text')el.value=el.value.trim();let val=(el.type=='checkbox')?el.checked:el.value;if(el.id in cfg)cfg[el.id]=val;else if(el.id in hub.cfg)hub.cfg[el.id]=val;cfg_changed=true;update_theme();}
function save_cfg(){localStorage.setItem('app_config',JSON.stringify(cfg));localStorage.setItem('hub_config',JSON.stringify(hub.cfg));}
function load_cfg(){if(localStorage.hasOwnProperty('app_config')){let cfg_r=JSON.parse(localStorage.getItem('app_config'));if(cfg.api_ver===cfg_r.api_ver){cfg=cfg_r;return;}}
localStorage.setItem('app_config',JSON.stringify(cfg));}
function load_cfg_hub(){if(localStorage.hasOwnProperty('hub_config')){let cfg_r=JSON.parse(localStorage.getItem('hub_config'));if(hub.cfg.api_ver===cfg_r.api_ver){hub.cfg=cfg_r;return;}}
localStorage.setItem('hub_config',JSON.stringify(hub.cfg));}
function apply_cfg(){for(let key in cfg){let el=EL(key);if(el==undefined)continue;if(el.type=='checkbox')el.checked=cfg[key];else el.value=cfg[key];}
for(let key in hub.cfg){let el=EL(key);if(el==undefined)continue;if(el.type=='checkbox')el.checked=hub.cfg[key];else el.value=hub.cfg[key];}}
async function cfg_export(){await copyClip(btoa(JSON.stringify(cfg))+';'+btoa(JSON.stringify(hub.cfg))+';'+btoa(encodeURIComponent(hub.export())));}
async function cfg_import(){try{let text=await navigator.clipboard.readText();text=text.split(';');try{cfg=JSON.parse(atob(text[0]));}catch(e){}
try{hub.cfg=JSON.parse(atob(text[1]));}catch(e){}
try{hub.import(decodeURIComponent(atob(text[2])));}catch(e){}
save_cfg();save_devices();showPopup('Import done');setTimeout(()=>location.reload(),1500);}catch(e){showPopupError('Wrong data');}}
function update_theme(){let v=themes[cfg.theme];let r=document.querySelector(':root');r.style.setProperty('--back',theme_cols[v][0]);r.style.setProperty('--tab',theme_cols[v][1]);r.style.setProperty('--font',theme_cols[v][2]);r.style.setProperty('--font2',theme_cols[v][3]);r.style.setProperty('--dark',theme_cols[v][4]);r.style.setProperty('--thumb',theme_cols[v][5]);r.style.setProperty('--black',theme_cols[v][6]);r.style.setProperty('--scheme',theme_cols[v][7]);r.style.setProperty('--font_inv',theme_cols[v][8]);r.style.setProperty('--shad',theme_cols[v][9]);r.style.setProperty('--ui_width',cfg.ui_width+'px');r.style.setProperty('--prim',intToCol(colors[cfg.maincolor]));r.style.setProperty('--font_f',cfg.font);EL('app_plugins').innerHTML='';addDOM('app_css','style',cfg.app_plugin_css,EL('app_plugins'));addDOM('app_js','script',cfg.app_plugin_js,EL('app_plugins'));let b='block';let n='none';let f='var(--font)';let f3='var(--font3)';display('local_block',hub.cfg.use_local?b:n);EL('local_label').style.color=hub.cfg.use_local?f:f3;display('pin_block',cfg.use_pin?b:n);EL('pin_label').style.color=cfg.use_pin?f:f3;}
function save_devices(){localStorage.setItem('devices',hub.export());}
function load_devices(){if(localStorage.hasOwnProperty('devices')){hub.import(localStorage.getItem('devices'));}}
let menu_f=false;let pin_id=null;async function show_screen(nscreen){if(focused)hub.dev(focused).fsStop();spinArrows(false);screen=nscreen;show_keypad(false);['conn_icons','test_cont','projects_cont','config','devices','controls','info','icon_menu','icon_cfg','files','ota','back','icon_refresh','footer_cont','conn'].forEach(e=>display(e,'none'));display('main_cont','block');EL('title').innerHTML=app_title;EL('title_row').style.cursor='pointer';let dev=hub.dev(focused);switch(screen){case'main':display('conn_icons','inline-block');display('devices','grid');display('icon_cfg','inline-block');display('icon_refresh','inline-block');display('footer_cont','block');EL('title_row').style.cursor='unset';showCLI(false);break;case'test':display('main_cont','none');display('test_cont','block');display('back','inline-block');EL('title').innerHTML='UI Test';break;case'projects':display('main_cont','none');display('projects_cont','block');display('back','inline-block');EL('title').innerHTML='Projects';break;case'ui':display('controls','block');display('icon_menu','inline-block');display('back','inline-block');display('icon_refresh','inline-block');display('conn','inline-block');EL('title').innerHTML=dev.info.name;break;case'config':display('conn_icons','inline-block');display('config','block');display('icon_cfg','inline-block');display('back','inline-block');EL('title').innerHTML='Config';break;case'info':display('info','block');display('icon_menu','inline-block');display('back','inline-block');display('conn','inline-block');display('icon_refresh','inline-block');EL('title').innerHTML=dev.info.name+'/info';show_info();break;case'files':display('files','block');display('icon_menu','inline-block');display('back','inline-block');display('conn','inline-block');display('icon_refresh','inline-block');EL('title').innerHTML=dev.info.name+'/fs';EL('file_upload_btn').innerHTML='Upload';break;case'ota':display('ota','block');display('icon_menu','inline-block');display('back','inline-block');display('conn','inline-block');EL('title').innerHTML=dev.info.name+'/ota';break;case'pin':display('back','inline-block');show_keypad(true);break;}}
function show_info(){let dev=hub.dev(focused);EL('ui_mode').value=dev.info.ui_mode;EL('main_width').value=dev.info.main_width;EL('ui_block_width').value=dev.info.ui_block_width;display('ui_block_width_cont',dev.info.ui_mode>=2?'flex':'none');EL('info_cli_sw').checked=EL('cli_cont').style.display=='block';EL('plugin_css').value=dev.info.plugin_css;EL('plugin_js').value=dev.info.plugin_js;EL('info_id').innerHTML=focused;EL('info_set').innerHTML=dev.info.prefix+'/'+focused+'/ID/set/*';EL('info_read').innerHTML=dev.info.prefix+'/'+focused+'/ID/read/*';EL('info_get').innerHTML=dev.info.prefix+'/hub/'+focused+'/get/*';EL('info_status').innerHTML=dev.info.prefix+'/hub/'+focused+'/status';display('reboot_btn',dev.module(Modules.REBOOT)?'block':'none');display('info_topics',dev.module(Modules.MQTT)?'block':'none');EL('info_version').innerHTML='';EL('info_net').innerHTML='';EL('info_memory').innerHTML='';EL('info_system').innerHTML='';}
function resize_h(){UiGauge.resize();UiGaugeR.resize();UiJoy.resize();UiDpad.resize();UiCanvas.resize();}
function test_h(){show_screen('test');}
function projects_h(){EL('projects').innerHTML='';show_screen('projects');loadProjects();}
function refresh_h(){if(focused)post(screen);else discover();}
async function back_h(){if(focused){let dev=hub.dev(focused);if(dev.fsBusy()){showPopupError(dev.fs_mode+' '+getError(HubError.Abort));dev.fsStop();}}
if(EL('fsbr_edit').style.display=='block'){editor_cancel();return;}
if(menu_f){Menu.deact();menu_show(0);return;}
switch(screen){case'ui':release_all();close_device();break;case'info':case'files':case'ota':Menu.deact();show_screen('ui');post('ui');break;case'config':config_h();break;case'pin':case'projects':case'test':show_screen('main');break;}}
function config_h(){if(screen=='config'){show_screen('main');if(cfg_changed){save_cfg();discover();}
cfg_changed=false;}else{show_screen('config');}}
function info_h(){Menu.deact();menu_show(0);if(hub.dev(focused).module(Modules.INFO))post('info');show_screen('info');EL('menu_info').classList.add('menu_act');}
function fsbr_h(){Menu.deact();menu_show(0);if(hub.dev(focused).module(Modules.FILES)){post('files');EL('fsbr_inner').innerHTML=waiter();}
display('fs_browser',hub.dev(focused).module(Modules.FILES)?'block':'none');display('fs_upload',hub.dev(focused).module(Modules.UPLOAD)?'block':'none');display('fs_create',hub.dev(focused).module(Modules.CREATE)?'block':'none');display('fs_format',hub.dev(focused).module(Modules.FORMAT)?'inline-block':'none');show_screen('files');EL('menu_fsbr').classList.add('menu_act');}
function format_h(){if(confirm('Format filesystem?'))post('format');}
function ota_h(){Menu.deact();menu_show(0);show_screen('ota');EL('menu_ota').classList.add('menu_act');let ota_t='.'+hub.dev(focused).info.ota_t;EL('ota_upload').accept=ota_t;EL('ota_upload_fs').accept=ota_t;EL('ota_url_f').value="http://flash"+ota_t;EL('ota_url_fs').value="http://filesystem"+ota_t;display('fs_otaf',hub.dev(focused).module(Modules.OTA)?'block':'none');display('fs_otaurl',hub.dev(focused).module(Modules.OTA_URL)?'block':'none');}
function manual_ip_h(ip){if(hub.http.discover_ip(ip,hub.cfg.http_port)){save_cfg();show_screen('main');}else showPopupError('Wrong IP');}
function update_ip_h(){if(isESP())EL('local_ip').value=window_ip();}
function menu_h(){menu_show(!menu_f);}
function devlink_h(){copyClip(devLink());}
function qr_h(){}
function devLink(){let qs=window.location.origin+window.location.pathname+'?';let info=hub.dev(focused).info;["id","prefix","ip","http_port"].forEach(x=>{if(info[x])qs+=`${x}=${info[x]}&`;});return qs.slice(0,-1);}
function ui_mode_h(el){hub.dev(focused).info.ui_mode=el.value;save_devices();display('ui_block_width_cont',el.value>=2?'flex':'none');}
function ui_width_h(el){hub.dev(focused).info.main_width=el.value;save_devices();}
function ui_block_width_h(el){hub.dev(focused).info.ui_block_width=el.value;save_devices();}
function ui_plugin_css_h(el){hub.dev(focused).info.plugin_css=el.value;save_devices();addDOM('device_css','style',el.value,EL('plugins'));}
function ui_plugin_js_h(el){hub.dev(focused).info.plugin_js=el.value;save_devices();addDOM('device_js','script',el.value,EL('plugins'));}
function menu_show(state){menu_f=state;let cl=EL('menu').classList;if(menu_f)cl.add('menu_show');else cl.remove('menu_show');EL('icon_menu').innerHTML=menu_f?'':'';display('menu_overlay',menu_f?'block':'none');}
function device_h(id){let dev=hub.dev(id);if(!dev||dev.conn==Conn.NONE)return;if(dev.info.PIN&&!dev.granted){pin_id=id;show_screen('pin');}else{open_device(id);}}
function open_device(id){focused=id;let dev=hub.dev(id)
EL('menu_user').innerHTML='';EL('conn').innerHTML=Conn.names[dev.conn];UiPlugin.enableStyle(id);addDOM('device_css','style',dev.info.plugin_css,EL('plugins'));addDOM('device_js','script',dev.info.plugin_js,EL('plugins'));let ctrls=EL('controls#'+id);if(ctrls){ctrls.style.visibility='visible';}
show_screen('ui');dev.focus();}
function close_device(){UiHook.reset();UiColor.reset();UiGauge.reset();UiGaugeR.reset();UiCanvas.reset();UiJoy.reset();UiDpad.reset();UiPlugin.disableStyle(focused);UiJS.disable();UiCSS.disable();EL('plugins').innerHTML='';let ctrls=EL('controls#'+focused);if(ctrls)ctrls.style.visibility='hidden';EL('ota_label').innerHTML="";errorBar(false);hub.dev(focused).unfocus();focused=null;show_screen('main');}
function delete_h(id){if(confirm('Delete '+id+'?')){hub.delete(id);EL(`device#${id}`).remove();return 1;}
return 0;}
function dev_up_h(id){hub.moveDevice(id,-1);render_devices();}
function dev_down_h(id){hub.moveDevice(id,1);render_devices();}
function showCLI(v){EL('bottom_space').style.height=v?'170px':'50px';display('cli_cont',v?'block':'none');if(v)EL('cli_input').focus();EL('info_cli_sw').checked=v;}
function printCLI(text,color){if(EL('cli_cont').style.display=='block'){if(EL('cli').innerHTML)EL('cli').innerHTML+='\n';let st=color?`style="color:${intToCol(color)}"`:'';EL('cli').innerHTML+=`<span ${st}>${text}</span>`;EL('cli').scrollTop=EL('cli').scrollHeight;}}
function toggleCLI(){EL('cli').innerHTML="";EL('cli_input').value="";showCLI(!(EL('cli_cont').style.display=='block'));}
function checkCLI(event){if(event.key=='Enter')sendCLI();}
function sendCLI(){post('cli','cli',EL('cli_input').value);EL('cli').innerHTML+="\n>"+EL('cli_input').value;EL('cli').scrollTop=EL('cli').scrollHeight;EL('cli_input').value="";}
function pass_type(v){EL('pass_inp').value+=v;let hash=EL('pass_inp').value.hashCode();if(pin_id){if(hash==hub.dev(pin_id).info.PIN){open_device(pin_id);EL('pass_inp').value='';hub.dev(pin_id).granted=true;}}else{if(hash==cfg.pin){display('password','none');startup();EL('pass_inp').value='';}}}
function check_type(arg){if(arg.value.length>0){let c=arg.value[arg.value.length-1];if(c<'0'||c>'9')arg.value=arg.value.slice(0,-1);}}
function show_keypad(v){if(v){display('password','block');EL('pass_inp').focus();}else{display('password','none');}}
let fs_arr=[];function showFsbr(fs,total,used){fs_arr=[];for(let path in fs)fs_arr.push(path);fs_arr=sortPaths(fs_arr,'/');let inner='';for(let i in fs_arr){if(fs_arr[i].endsWith('/')){inner+=`<div class="fs_file fs_folder drop_area" onclick="file_upload_path.value='${fs_arr[i]}'/*;file_upload_btn.click()*/" ondrop="file_upload_path.value='${fs_arr[i]}';uploadFile(event.dataTransfer.files[0],'${fs_arr[i]}')">${fs_arr[i]}</div>`;}else{let none="style='display:none'";inner+=`<div class="fs_file" onclick="openFSctrl(${i})">${fs_arr[i]}<div class="fs_weight">${(fs[fs_arr[i]] / 1000).toFixed(2)} kB</div></div>
<div id="fs#${i}" class="fs_controls">
<button ${hub.dev(focused).module(Modules.RENAME) ? '' : none} title="Rename" class="icon icon_btn_big" onclick="renameFile(${i})"></button>
<button ${hub.dev(focused).module(Modules.DELETE) ? '' : none} title="Delete" class="icon icon_btn_big" onclick="deleteFile(${i})"></button>
<button ${hub.dev(focused).module(Modules.FETCH) ? '' : none} title="Fetch" class="icon icon_btn_big" onclick="fetchFile(${i},'${fs_arr[i]}')"></button>
<label id="process#${i}"></label>
<a id="download#${i}" title="Download" class="icon icon_btn_big" href="" download="" style="display:none"></a>
<button id="open#${i}" title="Open" class="icon icon_btn_big" onclick="openFile(EL('download#${i}').href)" style="display:none"></button>
<button ${hub.dev(focused).module(Modules.UPLOAD) ? '' : none} id="edit#${i}" title="Edit" class="icon icon_btn_big" onclick="editFile(EL('download#${i}').href,'${i}')" style="display:none"></button>
</div>`;}}
if(total)inner+=`<div class="fs_info">Used ${(used / 1000).toFixed(2)}/${(total / 1000).toFixed(2)} kB [${Math.round(used / total * 100)}%]</div>`;else inner+=`<div class="fs_info">Used ${(used / 1000).toFixed(2)} kB</div>`;EL('fsbr_inner').innerHTML=inner;}
function openFSctrl(i){let current=EL(`fs#${i}`).style.display=='flex';document.querySelectorAll('.fs_controls').forEach(el=>el.style.display='none');if(!current)display(`fs#${i}`,'flex');}
function create_h(){post('mkfile',EL('file_create_path').value);}
function uploadFile(file,path){hub.dev(focused).upload(file,path);EL('file_upload').value='';}
function fetchFile(index,path){hub.dev(focused).fetch(index,path);}
function uploadOta(file,type){hub.dev(focused).uploadOta(file,type);EL('ota_upload').value='';EL('ota_upload_fs').value='';}
function deleteFile(i){if(hub.dev(focused).fsBusy()){showPopupError('FS busy');return;}
if(confirm('Delete '+fs_arr[i]+'?'))post('delete',fs_arr[i]);}
function renameFile(i){if(hub.dev(focused).fsBusy()){showPopupError('Busy');return;}
let path=fs_arr[i];let res=prompt('Rename '+path+' to',path);if(res&&res!=path)post('rename',path,res);}
let edit_idx=0;function editFile(data,idx){EL('editor_area').value=dataTotext(data);EL('editor_area').scrollTop=0;EL('edit_path').innerHTML=fs_arr[idx];display('files','none');display('fsbr_edit','block');edit_idx=idx;}
function editor_cancel(){display('files','block');display('fsbr_edit','none');}
function editor_save(){editor_cancel();let div=fs_arr[edit_idx].lastIndexOf('/');let path=fs_arr[edit_idx].slice(0,div);let name=fs_arr[edit_idx].slice(div+1);uploadFile(new File([EL('editor_area').value],name,{type:getMime(name),lastModified:new Date()}),path);}
function otaUrl(url,type){post('ota_url',type,url);showPopup('OTA start');}
window.onload=()=>{render_main();EL('hub_stat').innerHTML='GyverHub v'+app_version+' '+(isPWA()?'PWA ':'')+(isSSL()?'SSL ':'')+(isLocal()?'Local ':'')+(isESP()?'ESP ':'')+(isApp()?'App ':'');load_cfg();load_cfg_hub();if(isESP())hub.cfg.use_local=true;update_ip();update_theme();set_drop();key_change();handle_back();register_SW();if(cfg.use_pin)show_keypad(true);else startup();function register_SW(){}
function set_drop(){function preventDrop(e){e.preventDefault()
e.stopPropagation()}
['dragenter','dragover','dragleave','drop'].forEach(e=>{document.body.addEventListener(e,preventDrop,false);});['dragenter','dragover'].forEach(e=>{document.body.addEventListener(e,function(){document.querySelectorAll('.drop_area').forEach((el)=>{el.classList.add('active');});},false);});['dragleave','drop'].forEach(e=>{document.body.addEventListener(e,function(){document.querySelectorAll('.drop_area').forEach((el)=>{el.classList.remove('active');});},false);});}
function key_change(){document.addEventListener('keydown',function(e){switch(e.keyCode){case 116:if(!e.ctrlKey){e.preventDefault();refresh_h();}
break;case 192:break;if(focused){e.preventDefault();toggleCLI();}
break;default:break;}});}
function handle_back(){window.history.pushState({page:1},"","");window.onpopstate=function(e){window.history.pushState({page:1},"","");back_h();}}
function update_ip(){if(isESP()||window_ip()){EL('local_ip').value=window_ip();hub.cfg.local_ip=window_ip();}}}
function startup(){render_selects();render_info();apply_cfg();update_theme();show_screen('main');if('Notification'in window&&Notification.permission=='default')Notification.requestPermission();load_devices();let qs=window.location.search;if(qs){let params=new URLSearchParams(qs).entries();let data={};for(let param of params)data[param[0]]=param[1];if(!hub.dev(data.id))hub.addDevice(data);}
setTimeout(()=>{let ver=localStorage.getItem('version');if(!ver||ver!=app_version){alert('Версия '+app_version+'!\n'+'New version!');localStorage.setItem('version',app_version);}},1000);render_devices();hub.begin();discover();if(isESP()){for(let dev of hub.devices){if(window.location.href.includes(dev.info.ip)){dev.conn=Conn.HTTP;dev.conn_arr[Conn.HTTP]=1;device_h(dev.info.id);return;}}}}
function discover(){for(let dev of hub.devices){let id=dev.info.id;EL(`device#${id}`).className="device offline";display(`Serial#${id}`,'none');display(`BT#${id}`,'none');display(`HTTP#${id}`,'none');display(`MQTT#${id}`,'none');}
if(isESP()){hub.http.discover_ip(window_ip(),window.location.port??80);}
spinArrows(true);hub.discover();}
function search(){spinArrows(true);hub.search();}
function applyUpdate(id,data){if(data.func){let wid=EL('widget#'+id);if(wid&&wid.getAttribute("data-func")){UiFunc.update(focused,id,data);}
return;}
let el=CMP(id);if(el){let type=el.getAttribute('data-type');Widget.update(id,type,data);switch(type){case'input':UiInput.update(id,data);break;case'pass':UiPass.update(id,data);break;case'area':UiArea.update(id,data);break;case'button':UiButton.update(id,data);break;case'switch':UiSwitch.update(id,data);break;case'swicon':UiSwicon.update(id,data);break;case'label':UiLabel.update(id,data);break;case'title':UiTitle.update(id,data);break;case'display':UiDisplay.update(id,data);break;case'text':UiText.update(id,data);break;case'text_f':UiText_f.update(id,data);break;case'log':UiLog.update(id,data);break;case'date':UiDate.update(id,data);break;case'time':UiTime.update(id,data);break;case'datetime':UiDateTime.update(id,data);break;case'image':UiImage.update(id,data);break;case'confirm':UiConfirm.update(id,data);break;case'prompt':UiPrompt.update(id,data);break;case'table':UiTable.update(id,data);break;case'slider':UiSlider.update(id,data);break;case'spinner':UiSpinner.update(id,data);break;case'html':UiHTML.update(id,data);break;case'select':UiSelect.update(id,data);break;case'color':UiColor.update(id,data);break;case'led':UiLED.update(id,data);break;case'gauge':UiGauge.update(id,data);break;case'gauge_r':UiGaugeR.update(id,data);break;case'joy':UiJoy.update(id,data);break;case'dpad':UiDpad.update(id,data);break;case'flags':UiFlags.update(id,data);break;case'tabs':UiTabs.update(id,data);break;case'canvas':UiCanvas.update(id,data);break;case'stream':UiStream.update(id,data);break;}}else{let wid=EL('widget#'+id);if(wid){let type=wid.getAttribute('data-custom');Widget.update(id,type,data);switch(type){case'html':UiHTML.update(id,data);break;}}else{}}}
hub.onWsConnChange=(id,state)=>{if(id==focused){EL('conn').innerHTML=state?'HTTP/WS':'HTTP';}}
hub.onDeviceConnChange=(id,state)=>{if(id==focused)errorBar(!state);}
hub.onWaitAnswer=(id,state)=>{if(id==focused)spinArrows(state);}
hub.onPingLost=(id)=>{if(id==focused){let cmd='';switch(screen){case'ui':cmd='ui';break;case'info':cmd='info';break;case'files':cmd='files';break;default:cmd='ping';break;}
hub.dev(id).post(cmd);}}
hub.onSaveDevices=()=>{save_devices();}
hub.onAddDevice=(dev)=>{dev.ui_mode=0;dev.main_width=450;dev.ui_block_width=250;dev.plugin_css='';dev.plugin_js='';add_device(dev);}
hub.onUpdDevice=(dev)=>{EL(`name#${dev.id}`).innerHTML=dev.name?dev.name:'Unknown';EL(`device#${dev.id}`).title=`${dev.id} [${dev.prefix}]`;}
hub.onDiscoverEnd=()=>{if(screen=='main')spinArrows(false);}
hub.onDiscover=(id,conn)=>{EL(`device#${id}`).className="device";display(`${Conn.names[conn]}#${id}`,'inline-block');}
hub.onFsUploadStart=(id)=>{if(id!=focused)return;EL('file_upload_btn').innerHTML=waiter(22,'var(--font_inv)',false);}
hub.onFsUploadPerc=(id,perc)=>{if(id!=focused)return;showPopup(lang[cfg.lang].upload+'... '+perc+'%');}
hub.onFsUploadEnd=(id)=>{if(id!=focused)return;EL('file_upload_btn').innerHTML=lang[cfg.lang].upload;showPopup(`[${lang[cfg.lang].upload}] `+lang[cfg.lang].done);}
hub.onFsUploadError=(id,code)=>{if(id!=focused)return;EL('file_upload_btn').innerHTML=lang[cfg.lang].upload;showPopupError(`[${lang[cfg.lang].upload}] `+getError(code));}
hub.onFsFetchStart=(id,index)=>{if(id!=focused)return;display('download#'+index,'none');display('edit#'+index,'none');display('open#'+index,'none');display('process#'+index,'unset');EL('process#'+index).innerHTML='';}
hub.onFsFetchPerc=(id,index,perc)=>{if(id!=focused)return;EL('process#'+index).innerHTML=perc+'%';}
hub.onFsFetchEnd=(id,name,index,data)=>{if(id!=focused)return;display('download#'+index,'inline-block');EL('download#'+index).href=('data:'+getMime(name)+';base64,'+data);EL('download#'+index).download=name;display('open#'+index,'inline-block');display('edit#'+index,'inline-block');display('process#'+index,'none');}
hub.onFsFetchError=(id,index,code)=>{if(id!=focused)return;showPopupError(`[${lang[cfg.lang].fetch}] `+getError(code));EL('process#'+index).innerHTML=lang[cfg.lang].error;}
hub.onFetchStart=(id,name)=>{if(id==focused)setPlabel(name,'[fetch...]');}
hub.onFetchPerc=(id,name,perc)=>{if(id==focused)setPlabel(name,`[${perc}%]`);}
hub.onFetchEnd=(id,name,data,file)=>{if(id!=focused)return;switch(data.type){case'img':UiImage.apply(name,file);setPlabel(name,'');break;case'csv':UiTable.apply(name,dataTotext(file).replaceAll(/\\n/ig,"\n"));setPlabel(name,'');break;case'cv_img':data.img.src=file;setPlabel(name,'');break;case'text':UiText_f.apply(name,dataTotext(file));setPlabel(name,'');break;case'plugin_js':UiPlugin.applyScript(id,dataTotext(file));UiFunc.render(data.cont);break;case'plugin_css':UiPlugin.applyStyle(id,dataTotext(file));break;case'js':UiJS.apply(name,dataTotext(file),data.cont);break;case'css':UiCSS.apply(name,dataTotext(file),data.cont);break;case'html':UiHTML.apply(name,dataTotext(file));setPlabel(name,'');break;case'icon':UiButton.apply(name,dataTotext(file));setPlabel(name,'');break;case'ui_json':UiFile.apply(dataTotext(file),data);break;}}
hub.onFetchError=(id,name,data,code)=>{if(id!=focused)return;setPlabel(name,'[error]');switch(data.type){case'csv':case'img':break;}}
hub.onOtaStart=(id)=>{if(id!=focused)return;EL('ota_label').innerHTML=waiter(25,'var(--font)',false);}
hub.onOtaEnd=(id)=>{if(id!=focused)return;showPopup('[OTA] '+lang[cfg.lang].done);EL('ota_label').innerHTML=lang[cfg.lang].done;}
hub.onOtaError=(id,code)=>{if(id!=focused)return;showPopupError('[OTA] '+getError(code));EL('ota_label').innerHTML=lang[cfg.lang].error;}
hub.onOtaPerc=(id,perc)=>{if(id!=focused)return;EL('ota_label').innerHTML=perc+'%';}
hub.onOtaUrlEnd=(id)=>{if(id!=focused)return;showPopup('[OTA] '+lang[cfg.lang].done);}
hub.onOtaUrlError=(id,code)=>{if(id!=focused)return;showPopupError('[OTA url] '+getError(code));}
hub.onFsError=(id)=>{if(id==focused)EL('fsbr_inner').innerHTML=`<div class="fs_err">FS ${lang[cfg.lang].error}</div>`;}
hub.onError=(id,code)=>{if(id==focused)showPopupError(getError(code));}
hub.onAck=(id,name)=>{if(id==focused)setPlabel(name,'');}
hub.onUpdate=(id,name,data)=>{if(id!=focused)return;if(screen!='ui')return;applyUpdate(name,data);}
hub.onInfo=(id,info)=>{if(id==focused)showInfo(info);}
hub.onFsbr=(id,fs,total,used)=>{if(id==focused)showFsbr(fs,total,used);}
hub.onPrint=(id,text,color)=>{if(id==focused)printCLI(text,color);}
hub.onUi=(id,controls,conn,ip)=>{if(id==focused)showControls(id,controls,conn,ip);}
hub.onData=(id,data)=>{console.log('Data from '+id+': '+data);}
hub.onAlert=(id,text)=>{release_all();alert(hub.dev(id).info.name+': '+text);}
hub.onNotice=(id,text,color)=>{showPopup(hub.dev(id).info.name+': '+text,color);}
let push_timer=0;hub.onPush=(id,text)=>{let date=(new Date).getTime();if(date-push_timer>3000){push_timer=date;showNotif(hub.dev(id).info.name+': ',text);}}
hub.onHubError=(text)=>{showPopupError(text);}
